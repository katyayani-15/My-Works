#include <iostream>
using namespace std;
template <class T>
class one
{
 protected:
 T x,y;
 void display ( )
 {
 cout <<x;
 }
};
template <class T>
class two : public one <T>
{
 T z;
 public :
 two (T a, T b, T c)
 {
 x=a;
 y=b;
 z=c;
 }
 void show ( )
{
cout <<"\n x="<<x <<" y="<< y<<" z="<<z;
}
};
main ( )
{
 two <int> i(2,3,4) ;
 i.show( );
 two <float> f(1.1,2.2,3.3);
 f.show( );
}
