#include<iostream>
#include<math.h>
using namespace std;
int main()
{
	int n,num,sum=0,i=0,rem;
	cout<<"enter the number: ";
	cin>>n;
	num=n;
	while(n>0)
	{
		rem=n%10;
		sum=sum+rem*pow(2,i);
		n=n/10;
		i++;
	}
	cout<<"the decimal number of "<<num<<" is "<<sum<<endl;
	return 0;
}
