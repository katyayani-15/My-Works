#include<iostream>
using namespace std;
int main()
{
	int n;
	cout<<"enter the number: ";
	cin>>n;
	if(n>0)
	{
		cout<<""<<n<<" is a possitive number";
	}
	else if(n==0)
	{
		cout<<""<<n<<" is equals to zero";
	}
	else
	{
		cout<<""<<n<<" is negitive number";
	}
	return 0;
}
