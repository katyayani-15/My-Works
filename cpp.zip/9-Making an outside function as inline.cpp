#include<iostream>
using namespace std;
class item
{
	private:
		int codeno;
		float price;
		int qty;
	public:
		void show(void);
};
inline void item::show()
{
	codeno=213;
	price=2022;
	qty=150;
	cout<<"Codeno="<<codeno;
	cout<<"\nPrice="<<price;
	cout<<"\nQuantity="<<qty;
}
main()
{
	item one;
	one.show();
}
