#include<iostream>
using namespace std;
int main()
{
	int a,b,c;
	cout<<"enter the values of a and b: ";
	cin>>a;
	cin>>b;
	c=a&b;
	cout<<"a&b is = "<<c<<endl;
	c=a|b;
	cout<<"a|b is = "<<c<<endl;
	c=a^b;
	cout<<"a^b is = "<<c<<endl;
	c=~a;
	cout<<"~a is = "<<c<<endl;
	c=a<<2;
	cout<<"a<<2 is = "<<c<<endl;
	c=a>>2;
	cout<<"a>> is = "<<c<<endl;
	return 0;
}
