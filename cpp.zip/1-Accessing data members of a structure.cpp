#include<stdio.h>
struct item
{
    int codeno;
	float prize;
	int qty;	
};
main()
{
	struct item a,*b;
	a.codeno=123;
	a.prize=150.75;
	a.qty=150;
	printf("With simple variable:");
	printf("\nCodeno:%d",a.codeno);
	printf("\nPrize:%d",a.prize);
	printf("\nQty:%d",a.qty);
	b->codeno=124;
	b->prize=200.75;
	b->qty=75;
	printf("\nWith pointer variable:");
	printf("\nCodeno:%d",b->codeno);
	printf("\nPrize:%d",b->prize);
	printf("\nQty:%d",b->qty);
}
