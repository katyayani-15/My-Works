#include<iostream>
using namespace std;
struct item
{
	int codeno;
	float prize;
	int qty;
};
main()
{
	item a,*b;
	a.codeno=123;
	a.prize=150.75;
	a.qty=150;
	cout<<"With simple variable";
	cout<<"\nCodeno:"<<a.codeno;
	cout<<"\nPrize:"<<a.prize;
	cout<<"\nQty:"<<a.qty;
	b->codeno=124;
	b->prize=200.75;
	b->qty=75;
	cout<<"\nWith pointer to structure:";
	cout<<"\nCodeno:"<<b->codeno;
	cout<<"\nPrize:"<<b->prize;
	cout<<"\nQty:"<<b->qty;
}
