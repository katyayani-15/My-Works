#include <iostream>
using namespace std;
class bita
{
 private:
 int c;
 int k;
 public :
 void plus( )
 {
 c+=2;
 k+=2;
 }
 void show( )
 {
 cout <<" c= "<<c<<"\n";

 cout <<" k= "<<k;
 }
};
main( )
{
 static bita A;
 A.plus( );
 A.show( );
}
