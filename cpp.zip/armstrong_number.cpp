#include<iostream>
#include<math.h>
using namespace std;
int main()
{
	int n,rem,num,sum=0;
	cout<<"enter the number: ";
	cin>>n;
	num=n;
	while(n>0)
	{
		rem=n%10;
		sum=sum+pow(rem,3);
		n=n/10;
	}
	if(num==sum)
	{
		cout<<""<<num<<" is armstrong number";
	}
	else
	{
		cout<<""<<num<<" is not armstrong number";
	}
	return 0;
}
