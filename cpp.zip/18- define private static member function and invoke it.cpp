#include <iostream>
using namespace std;
class bita
{
 private :
 static int c;
 static void count( ) { c++; }
public:
static void display( )
{
 count( );
 cout <<"\nValue of c : "<<c;
 }
};
int bita ::c=0;
main( )
{
 bita:: display( );
 bita::display( );
}
