#include<iostream>
using namespace std;
int main()
{
	int num1,num2;
	cout<<"enter your numbers a and b: ";
	cin>>num1;
	cin>>num2;
	cout<<"a+b = "<<(num1+num2)<<endl;
	cout<<"a-b = "<<(num1-num2)<<endl;
	cout<<"a*b = "<<(num1*num2)<<endl;
	cout<<"a/b = "<<(num1/num2)<<endl;
	return 0;
}
