#include<iostream>
using namespace std;
int main()
{
	int num1;
	cout<<"enter the number: ";
	cin>>num1;
	num1++;
	cout<<"num++ is: "<<num1<<endl;
	num1--;
	cout<<"num-- is: "<<num1<<endl;
	++num1;
	cout<<"++num is: "<<num1<<endl;
	--num1;
	cout<<"--num is: "<<num1<<endl;
	return 0;
}
