#include<iostream>
using namespace std;
int main()
{
	int num,count=0,i;
	cout<<"enter the number: ";
	cin>>num;
	if(num==1)
	{
		cout<<"prime number starts from 2";
	}
	else
	{
		for(i=2;i<num;i++)
	{
		if(num%i==0)
		{
			count++;
		}
	}
	if(count==0)
	{
		cout<<"given number is prime number";
	}
	else
	{
		cout<<"given number is not prime";
	}
	}

}
