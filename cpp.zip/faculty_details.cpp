#include<iostream>
using namespace std;
int main()
{
	while(1)
	{
		int n;
		cout<<"\nKnow The Details Of The Faculties\n";
		cout<<"1:C++\n2:DS\n3:Computer Drafting\n4:Physics\n5:Maths\n6:ES\n7:QUIT\n";
		cout<<"Enter your choice: ";
		cin>>n;
		switch(n)
		{
			case 1:
				cout<<"\nSathis Sir\nAssistant Professor\nDepartment of CSE\nMob no:9441116070\n";
				break;
				case 2:
					cout<<"\nAnil Sir\nAssistant Professor\nDepartment of CSE\nMob no:9703843263\n";
					break;
					case 3:
						cout<<"\nSrinivash Naik\nAssistant Professor\nDepartment of MECH\nMob no:7416261525\n";
						break;
						case 4:
							cout<<"\nShiva Narayana Sir\nAssistant Professor\nDepartment of MECH\nMob no:**********\n";
							break;
							case 5:
								cout<<"\nGnaneshwar Rao Sir\nAssistant Professor\nDepartment of MECH\nMob no:**********\n";
								break;
								case 6:
									cout<<"\nSubhasini Madam\nAssistant Professor\nDepartment of BIOLOGY\nMob no:**********\n";
									break;
									case 7:exit(1);
									break;
									default:
										cout<<"invalid selection\n";
										break;
							
		}
	}
}
