#include<iostream>
using namespace std;
int main()
{
	int a,b,c,sum;
	float avg;
	cout<<"enter the marks of the student\n";
	cout<<"C++ language: ";
	cin>>a;
	cout<<"C language: ";
	cin>>b;
	cout<<"python: ";
	cin>>c;
	sum=a+b+c;
	cout<<"the sum of the marks is: "<<sum<<endl;
	avg=sum/3;
	cout<<"the average of the marks is: "<<avg<<endl;
	return 0;
}
