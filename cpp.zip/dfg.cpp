#include<iostream>
using namespace std;
class A
{ public:
 int a;
 private:
 int b;
 public:
 A( ){a=10,b=20;}
 ~A( )
 {
     cout<<"a="<<a;
     cout<<"b="<<b;
 }
};
int main( )
{ A a;}
