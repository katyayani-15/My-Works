#include<iostream>
using namespace std;
int main()
{
	int num,i,fact=1;
	cout<<"enter the number: ";
	cin>>num;
	for(i=1;i<=num;i++)
	{
		fact=fact*i;
	}
	cout<<"the factorial "<<num<<" is: "<<fact<<endl;
	return 0;
}
