#include<iostream>
using namespace std;
class sample
{
	private:
		int num;
		void show1()
		{
			cout<<"Inside the private section:";
			cout<<"\nEnter a number:";
			cin>>num;
			cout<<"Number is:"<<num;
		}
	public:
		int num1;
		void show()
		{
			show1();
			cout<<"\nInside the public section:";
			cout<<"\nEnter a number:";
			cin>>num1;
			cout<<"Number is:"<<num1;
			show2();
		}
	protected:
		int num2;
		void show2()
		{
			cout<<"\nInside the protected section:";
			cout<<"\nEnter a number:";
			cin>>num2;
			cout<<"Number is:"<<num2;
		}
};
main()
{
	sample s;
	s.show();
}
