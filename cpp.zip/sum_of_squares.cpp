#include<iostream>
using namespace std;
int main()
{
	int n,sum;
	cout<<"enter the number: ";
	cin>>n;
	sum=(n*(n+1)*((2*n)+1))/6;
	cout<<"sum of squares upto "<<n<<" is: "<<sum<<endl;
	return 0;
}
