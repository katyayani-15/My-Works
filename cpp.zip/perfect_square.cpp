#include<iostream>
using namespace std;
int main()
{
	int num,i;
	cout<<"enter the number: ";
	cin>>num;
	for(i=1;i<=num;i++)
	{
		if(num==i*i)
		{
			cout<<""<<num<<" is perfect square";
		}
	}
return 0;
}

