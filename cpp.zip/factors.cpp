#include<iostream>
using namespace std;
int main()
{
	int num,fact=1,i;
	cout<<"enter the number: ";
	cin>>num;
	cout<<"the factors are\n";
	for(i=1;i<=num;i++)
	{
    	if(num%i==0)
    	{
    		cout<<i<<endl;
		}
	}
	return 0;
}
	
