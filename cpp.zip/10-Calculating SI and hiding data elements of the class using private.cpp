#include<iostream>
using namespace std;
class interest 
{
	private:
		float p_amount;
		float rate;
		float period;
		float interest;
		float t_amount;
	public:
		void in()
		{
			cout<<"Principle amount:";
			cin>>p_amount;
			cout<<"Rate of Interest:";
			cin>>rate;
			cout<<"Number of Years:";
			cin>>period;
			interest=(p_amount*period*rate)/100;
			t_amount=interest+p_amount;
		}
		void show()
		{
			cout<<"Principle Amount:"<<p_amount;
			cout<<"\nRate of Interest:"<<rate;
			cout<<"\nNumber of Years:"<<period;
			cout<<"\nInterest:"<<interest;
			cout<<"\nTotal amount:"<<t_amount;
		}
};
main()
{
	interest r;
	r.in();
	r.show();
}
