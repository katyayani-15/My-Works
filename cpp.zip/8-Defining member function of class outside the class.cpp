#include<iostream>
using namespace std;
class item
{
	private:
		int codeno;
		float price;
		int qty;
	public:
		void show(void);
};
void item::show()
{
	codeno=101;
	price=2342;
	qty=122;
	cout<<"Codeno="<<codeno;
	cout<<"\nPrice="<<price;
	cout<<"\nQuantity="<<qty;
}
main()
{
	item one;;
	one.show();
}
