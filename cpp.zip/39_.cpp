#include <iostream>

using namespace std;

int main()
{
    char sample[] = "KATYAYANI";
  	cout<<"Name:KATYAYANI"<<endl;
    cout<<"ID:S170464"<<endl;
    cout<<"Class:CSE-1D"<<endl;
    cout << sample << " -  computer science and engineering";

    return 0;
}

