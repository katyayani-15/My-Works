#include<iostream>
using namespace std;
class first;
 class second
 {
 int s;
 public :
 void getvalue( )
 {
 cout <<"\nEnter a number : ";
 cin >>s;
 }
friend void sum (second, first);
};
class first
{
 int f;
 public :
void getvalue( )
{
 cout <<"\nEnter a number : " ;
 cin >>f;
}
friend void sum (second , first);
};
 void sum (second d, first t)
 {
 cout <<"\n Sum of two numbers : " <<t.f + d.s;
 }
main( )
{
 first a;
 second b;
 a.getvalue( );
 b.getvalue( );
 sum(b,a);
}
