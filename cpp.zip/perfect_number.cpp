#include<iostream>
using namespace std;
int main()
{
	int num,n,sum=0,i;
	cout<<"enter the number: ";
	cin>>num;
	n=num;
	for(i=1;i<num;i++)
	{
		if(num%i==0)
		{
			sum=sum+i;
		}
	}
	if(sum==n)
	{
		cout<<""<<num<<" is a perfect number";
	}
	else
	{
		cout<<""<<num<<" is a not perfect number";
	}
	return 0;
}
