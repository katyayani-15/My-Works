#include<iostream>
#include<math.h>
using namespace std;
int main()
{
	int n,i;
	cout<<"enter the number: ";
	cin>>n;
	for(i=1;i<=n;i++)
	{
		if(n==pow(i,3))
		{
			cout<<""<<n<<" is perfect qube";
		}
	}
	return 0;
}
