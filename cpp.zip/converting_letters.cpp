#include<iostream>
#include<ctype.h>
using namespace std;
int main()
{
	char ch;
	cout<<"enter the charecter: ";
	cin>>ch;
	if(ch>=65 && ch<=90)
	{
		ch=ch+32;
		cout<<"you enterd uppercase letter\nlowercase letter is: "<<ch<<endl;
	}
	else
	{
		ch=ch-32;
		cout<<"you entered lowercase letter\nuppercase letter is: "<<ch<<endl;
	}
}
