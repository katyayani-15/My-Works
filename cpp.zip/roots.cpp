#include<iostream>
#include<math.h>
using namespace std;
int main()
{
	int a,b,c,dis;
	float r1,r2,real,img;
	cout<<"enter the values of a,b,c: ";
	cin>>a;
	cin>>b;
	cin>>c;
	dis=(b*b)-4*a*c;
	if(dis>0)
	{
		r1=(-b+sqrt(dis))/(2*a);
		r2=(-b-sqrt(dis))/(2*a);
		cout<<"the roots are: "<<r1<<endl;
		cout<<r2<<endl;
	}
	else if(dis==0)
	{
		r1=r2=-b/(2*a);
		cout<<"the roots are: "<<r1<<endl;
		cout<<r2<<endl;
	}
	else
	{
		real=-b/(2*a);
		img=sqrt(-dis)/(2*a);
		cout<<"real and imaginary roots are: "<<real<<endl;
		cout<<img<<endl;
	}
	return 0;
}
