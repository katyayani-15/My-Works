#include<iostream>
using namespace std;
int main()
{
	int a,b,c;
	cout<<"enter the numbers a and b: ";
	cin>>a;
	cin>>b;
	c=a;
	a=b;
	b=c;
	cout<<"a is = "<<a<<"\n"<<"b is = "<<b;
	return 0;
}
