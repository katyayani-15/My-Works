#include <stdio.h>
#include <stdlib.h>
struct node
{
	int data;
	struct node* next;
};
struct node* root = NULL; 
void append()
{
	struct node *temp,*ptr;
	ptr=root;
	temp=(struct node*)malloc(sizeof(struct node));
	printf("\nENTER THE ELEMENT TO BE APPENDED:");
	scanf("%d",temp->data);
	temp->next=NULL;
	if(root==NULL)
	{
		
		root=temp;
	}
	else
		{
		while(ptr->next!=NULL)
		{
			ptr=ptr->next;
		}
		ptr->next=temp;
	}
}
	display()
	{
		
		struct node* ptr;
		ptr=root;
		
		
			if(root==NULL)
			{
				printf("\nNO ELEMENT IS PRESENT IN THE LIST");
			}
			else
			{
				while(ptr!=NULL)
			{
				printf("\t%d\t",ptr->data);
				ptr=ptr->next;
			}
			}
		
	}
	int	length()
	{
		
		struct node* ptr;
		ptr=root;
		int c=0;
		{
			if(root==NULL)
			{
				printf("\nNO ELEMENT IS PRESENT IN THE LIST");
			}
			else
			{
				while(ptr!=NULL)
			{
				c++;
				ptr=ptr->next;
			}
			return c;
			}
		}
		
	}
	beginnig()
	{
	struct node *temp;
	temp=(struct node*)malloc(sizeof(struct node));
	printf("\nENTER THE ELEMENT TO BE INSERTED AT BEGINNING:");
	scanf("%d",temp->data);
	temp->next=NULL;
	if(root==NULL)
	{
		root=temp;
	}
	else
	{
		temp->next=root;
		root=temp;
	}
	}


int main()
{
	while(1)
	{
	int ch;
	int len;
	printf("\n1.APPEND");
	printf("\n2.ADD AT BEGINNING");
	printf("\n3.ADD AT");
	printf("\n4.DISPLAY");
	printf("\n5.LENGTH");
	printf("\nTHE LENGTH IS %d",length());
	printf("\n6.DELETE");
	printf("\n7.QUIT");
	printf("\nENTER YOUR CHOICE:");
	scanf("%d",&ch);
    
    switch(ch)
    {
    case 1:append();
    	break;
    case 2:beginnig();
    	break;
    case 3:
    	break;
    case 4:display();
    	break;
    case 5:printf("\nTHE LENGTH IS %d",length());
    	break;
    	
    case 6:
    	break;
	case 7:exit(1);
	    break;
	default:printf("ENTER A VALIED OPTION");
	    break;	
    }
    }
}
