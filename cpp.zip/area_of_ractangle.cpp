#include<iostream>
using namespace std;
int main()
{
	int l,b;
	float area;
	cout<<"enter the length and bredth of ractangle: ";
	cin>>l;
	cin>>b;
	area=l*b;
	cout<<"the area of the ractangle is: "<<area<<endl;
	return 0;
}
