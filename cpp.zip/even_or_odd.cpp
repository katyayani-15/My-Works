#include<iostream>
using namespace std;
int main()
{
	int n;
	cout<<"enter the number: ";
	cin>>n;
	if(n%2==0)
	{
		cout<<""<<n<<" is an even integer";
	}
	else
	{
		cout<<""<<n<<" is an odd integer";
	}
	
return 0;
}
