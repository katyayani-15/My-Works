#include<iostream>
using namespace std;
int fact(int x)
{
	int i,val=1;
	for(i=1;i<=x;i++)
	{
		val=val*i;
	}
	return val;
}
int main()
{
	int n,r,res;
	cout<<"enter the numbers: ";
	cin>>n>>r;
	res=fact(n)/fact(n-r);
	cout<<"the nPr is: "<<res<<endl;
	return 0;
}
