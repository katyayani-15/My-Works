#include<iostream>
using namespace std;
int main()
{
	bool a=true;
	bool b=false;
	cout<<"a&&b== "<<(a&&b)<<endl;
	cout<<"a||b== "<<(a||b)<<endl;
	cout<<"!(a&&b)== "<<!(a&&b)<<endl;
	return 0;
}
