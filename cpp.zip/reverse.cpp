#include<iostream>
using namespace std;
int main()
{
	int n,sum=0,num,rem;
	cout<<"enter the number: ";
	cin>>n;
	while(n>0)
	{
		rem=n%10;
		sum=rem+sum*10;
		n=n/10;
	}
	cout<<"reverse of a given number is: "<<sum<<endl;
}
