#include<iostream>
using namespace std;
int fact(int x)
{
	int i,val=1;
	for(i=1;i<=x;i++)
	{
		val=val*i;
	}
	return val;
}
int main()
{
	int n,r,res,re,ncr;
	cout<<"enter the n and r: ";
	cin>>n;
	cin>>r;
	res=fact(n)/fact(n-r);
	re=fact(r);
	ncr=res/re;
	cout<<"the ncr is: "<<ncr<<endl;
	return 0;
	
}
