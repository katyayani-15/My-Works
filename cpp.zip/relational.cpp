#include<iostream>
using namespace std;
int main()
{
	int a,b;
	cout<<"enter the values of a and b: ";
	cin>>a;
	cin>>b;
	if(a==b)
	cout<<"a and b are equal"<<endl;
	else
	cout<<"a and b are not equal"<<endl;
	if(a!=b)
	cout<<"a and b are not equal"<<endl;
	else
	cout<<"a and b are equal"<<endl;
	if(a>b)
	cout<<"a is greater than b"<<endl;
	else
	cout<<"b is greater than a"<<endl;
	if(a>=b)
	cout<<"a is greater or equal to b"<<endl;
	return 0;
}
