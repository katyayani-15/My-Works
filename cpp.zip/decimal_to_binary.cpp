#include<iostream>
#include<math.h>
using namespace std;
int main()
{
	int n,rem,i=0,sum=0,num;
	cout<<"enter the number: ";
	cin>>n;
	num=n;
	while(n>0)
	{
		rem=n%2;
		sum=sum+rem*pow(10,i);
		n=n/2;
		i++;
	}
	cout<<"the binary code of "<<num<<" is "<<sum<<endl;
}
