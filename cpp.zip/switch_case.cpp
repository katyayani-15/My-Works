#include<iostream>
using namespace std;
int main()
{
	int a,b,sum,sub,mul,div,n;
	cout<<"enter the numbers: ";
	cin>>a>>b;
	sum=a+b;
	sub=a-b;
	mul=a*b;
	div=a/b;
	while(1)
	{
	cout<<"\n1-for addition\n2-for subtraction\n3-for multiplication\n4-for division\n5-for QUIT\n";
	cout<<"enter your choice: ";
	cin>>n;
	switch(n)
	{
		case 1:
			cout<<"\nsum is "<<sum<<endl;
			break;
			case 2:
			cout<<"\nsubtraction is"<<sub<<endl;
			break;
			case 3:
			cout<<"\nmultiplication is"<<mul<<endl;
			break;
			case 4:
			cout<<"\ndivision is"<<div<<endl;
			break;
            case 5:exit(1);
            break;
            default:
            	cout<<"INVALID SELECTION\n";
		
		
	}
}
}
