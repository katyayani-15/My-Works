#include<stdio.h>
main()
{
    char a[]={"FFLLLFFLFE"};
    int L=1,x=0,y=0;
    int i;
    for(i=0;a[i]!='\0';i++)
    {
        if(a[i]=='L')
        {
            L++;
        }

        else if(a[i]=='F')
        {
            if(L==2)
            {
                y++;
            }
            else if(L==3)
            {
                x--;
            }
            else if(L==4)
            {
                y--;
            }
            else if(L==5||L==1)
            {
                x++;
            }
        }
           else
        {
            printf("(%d,%d)",x,y);
            break;
        }
    }
}
