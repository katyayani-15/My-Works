#include<iostream>
using namespace std;
int main()
{
	int n,x1=0,x2=1,i,nt,k=0;
	cout<<"enter the number: ";
	cin>>n;
	for(i=0;i<n;i++)
	{
		cout<< x1<<endl;
		if(x1%2==0)
        {
            k+=x1;
        }
		nt=x1+x2;
		x1=x2;
		x2=nt;
	}
	cout<<"k:"<<k;
	return 0;
}
