#include<iostream>
using namespace std;
class item
{
	private:
		int codeno;
		float price;
		int qty;
		public:
			void show()
			{
				codeno=125;
				price=195;
				qty=200;
				cout<<"Codeno="<<codeno;
				cout<<"\nPrice="<<price;
				cout<<"\nQuantity="<<qty;
			}
};
main()
{
	item one;
	one.show();
}
