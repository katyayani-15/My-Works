#include<iostream>
using namespace std;
class A
{
	protected:
		int num;
		void display()
		{
			cout<<num;
		}
};
main()
{
	A a;
	a.num=100;
	a.display();
}
