#include<iostream>
using namespace std;
int main()
{
	char ch;
	cout<<"enter the charecter: ";
	cin>>ch;
	if(ch=='a'||ch=='e'||ch=='i'||ch=='o'||ch=='u'||ch=='A'||ch=='E'||ch=='I'||ch=='O'||ch=='U')
	{
		cout<<"enterd charecter is vowel";
	}
	else
	{
		cout<<"enterd charecter is consonant";
	}
	return 0;
}
