#include<iostream>
using namespace std;
struct item
{
	private:
		int codeno;
		float price;
		int qty;
		void values()
		{
			codeno=125;
			price=195;
			qty=200;
		}
	public:
		void show()
		{
			values();
			cout<<"Codeno="<<codeno;
			cout<<"\nPrice="<<price;
			cout<<"\nQuantity="<<qty;
		}
};
main()
{
	item one;
	one.show();
}
