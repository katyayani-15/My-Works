#include<iostream>
using namespace std;
int main()
{
	int a,b;
	cout<<"enter the numbers a and b: ";
	cin>>a;
	cin>>b;
	if(a>b)
	{
		cout<<"a is greater than b";
	}
	else
	{
		cout<<"b is greater than a";
	}
	return 0;
}
