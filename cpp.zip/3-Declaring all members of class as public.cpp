#include<iostream>
using namespace std;
class item
{
	public:
		int codeno;
		float prize;
		int qty;
};
main()
{
	item one;
	one.codeno=123;
	one.prize=123.45;
	one.qty=150;
	cout<<"Codeno="<<one.codeno;
	cout<<"\nPrize="<<one.prize;
	cout<<"\nQty="<<one.qty;
}

