#include<iostream>
using namespace std;
class ac
{
 private:
 char name[15];
 int acno;
 float bal;
public:
void read( )
{
 cout <<"\nName :" ;
 cin >>name;
 cout <<"\nA/c No. :";
 cin >>acno;
 cout <<"\n Balance :";
 cin >>bal;
}
friend void showbal(ac );
};
void showbal (ac a)
{
 cout <<"\n Balance of A/c no. " <<a.acno <<" is Rs." <<a.bal;
}
int main( )
{
 ac k;
 k.read( );
 showbal(k);
}

