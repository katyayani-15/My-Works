#include<iostream>
using namespace std;
class life
{
 int mfgyr;
 int expyr;
 int yr;
 public :
 void getyrs( )
 {
 cout <<"\nManufacture Year : ";
 cin >>mfgyr;
 cout <<"\n Expiry Year : ";
 cin >>expyr;
 }
 void period ( life);
 };
 void life :: period (life y1)
 {
 yr=y1.expyr-y1.mfgyr;
 cout <<"Life of the product : " <<yr <<" Years";
 }
main( )
{
 life a1;
 a1.getyrs( );
 a1.period(a1);
}
