#include<iostream>
#include<math.h>
using namespace std;
main()
{
    int a,b,c,dis;
    cout<<"enter the values of a,b,c: ";
    cin>>a;
    cin>>b;
    cin>>c;
    dis=b*b-4*a*c;
    cout<<"discriminate:"<<dis;
    cout<<"1.If the dis is greater than zero(dis>0)\n2.If the dis is equal to zero(dis==0)\n3.If the dis is less than zero(dis<0)";
    switch(ch)
    {
        case 1:if(dis>0)
        {
            r1=
        }
    }

}

