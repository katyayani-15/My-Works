#include<iostream>
using namespace std;
int main()
{
	int n,sum;
	cout<<"enter the number: ";
	cin>>n;
	sum=((n*(n+1))*(n*(n+1)))/4;
	cout<<"sum of natural numbers upto "<<n<<" is: "<<sum<<endl;
	return 0;
}
