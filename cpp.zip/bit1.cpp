#include<iostream>
using namespace std;
class A
{ public:
 int a;
 A( ) {a=10;}
};
 class B : public A
 { public:
 int b;
 B( ) { b=20; }
 ~ B( ) { cout <<"\n a= "<<a <<" b = "<<b;}
};
 int main ( ) { B( );}
