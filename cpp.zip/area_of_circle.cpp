#include<iostream>
using namespace std;
int main()
{
	int r;
	float area;
	cout<<"enter the radius: ";
	cin>>r;
	area = 3.14*(r*r);
	cout<<"the area of circle is: "<<area<<endl;
	return 0;
}
