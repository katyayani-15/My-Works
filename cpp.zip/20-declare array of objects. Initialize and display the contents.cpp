#include <iostream>
using namespace std;
class player
{
 private:
 char name [20];
 int age;
 public:
 void input (void);
 void display (void);
};
void player :: input ( )
{
 cout <<"\n Enter Player name : ";
 cin>>name;
 cout <<" Age : ";
 cin>>age;
}
void player :: display ( )
{
 cout <<"\n Player name : "<<name;
 cout <<"\n Age : "<<age;
}
main( )
{
 int i;
 player cricket[3];
 cout <<"\n Enter Name and age of 3 players ";
 for(i=0;i<3;i++)
 cricket[i].input ( );
 for(i=0;i<3;i++)
 cricket[i].display ( );
 return 0;
}
