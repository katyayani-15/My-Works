#include<iostream>
#include<stdlib.h>
using namespace std;
template <class K>
class node
{
    private:
    K data;
    node *link;
};
template <class K>
class lis
{
private:
    node<K>* temp;
    temp root=NULL;
    temp
} ;
struct node *root=NULL;
int len;
void append()
{
    struct node*temp;
    temp=(struct node*)malloc(sizeof(struct node));
    cout<<"enter the data:";
    cin>>temp->data;
    temp->link=NULL;
    if(root==NULL)
    {
        root=temp;
    }
    else
    {
        struct node *s;
        s=root;
        while(s->link!=NULL)
        {
            s=s->link;
        }
        s->link=temp;
    }
}
int length()
{
    int count=0;
    struct node *temp;
    temp=root;
    while(temp!=NULL)
    {
        count++;
        temp=temp->link;

    }
    return count;
}
void display()
{
    struct node *temp;
    temp=root;
    if(temp==NULL)
    {
        cout<<"no nodes to display";
    }
    else
    {
        while(temp!=NULL)
        {
            cout<<"->"<<temp->data;
            temp=temp->link;
        }
    }
}
void addatbegin()
{
    struct node *temp;
    temp=(struct node*)malloc(sizeof(struct node));
    cout<<"enter node data:";
    cin>>temp->data;
    temp->link=NULL;
    if(root==NULL)
    {
        root=temp;
    }
    else
    {
        temp->link=root;
        root=temp;
    }
}
void addatafter()
{
    struct node *temp,*p;
    int loc ,i=1;
    cout<<"enter the location:";
    cin>>loc;
    if(loc>length())
    {
        cout<<"no nodes present";
    }
    else
    {
        p=root;
        while(i<loc)
        {
            p=p->link;
            i++;
        }
        temp=(struct node*)malloc(sizeof(struct node));
        cout<<"enter the data:";
        cin>>temp->data;
        temp->link=NULL;
        temp->link=p->link;
        p->link=temp;
    }
}
void delete1()
{
    struct node *temp;
    int loc;
    cout<<"enter the location:";
    cin>>loc;
    if(loc>length())
    {
        cout<<"invalid location";
    }
    else if(loc==1)
    {
        temp=root;
        root=temp->link;
        temp->link=NULL;
        free(temp);
    }
    else
    {
        int i=1;
        struct node *k=root,*s;
        while(i<loc-1)
        {
            k=k->link;
            i++;
        }
        s=k->link;
        k->link=s->link;
        s->link=NULL;
        free(s);
    }
}
main()
{
    int ch;
    while(1)
    {
       cout<<"\nsingle linked list operation:\n1.Append\n2.Add at begin\n3.Add at after\n4.Length\n5.Display\n6.Delete\n7.Quit\nenter your choice:";
        cin>>ch;
        switch(ch)
        {
            case 1:append();
            break;
            case 2:addatbegin();
            break;
            case 3:addatafter();
            break;
            case 4:len=length();
            cout<<"length of the list :\n"<<len;
            break;
            case 5:display();
            break;
            case 6: delete1();
            break;
            case 7: exit(1);
            break;
            default:cout<<"invalid choice\n";




        }
    }
}

