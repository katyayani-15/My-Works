#include<iostream>
using namespace std;
int main()
{
	int l,b;
	float area;
	cout<<"enter the length and breadth of the triangle: ";
	cin>>l;
	cin>>b;
	area=(0.5*(l*b));
	cout<<"the area of the triangle is: "<<area<<endl;
	return 0;
}
