#include<iostream>
using namespace std;
class access
{
	private:
		int p;
		void getp()
		{
			cout<<"In gtep(),Enter value of p:";
			cin>>p;
		}
	public:
		int h;
		void geth()
		{
			cout<<"In geth():"<<endl;
			getp();
			getm();
			cout<<"p="<<p<<endl<<"h="<<h<<endl<<"m="<<m;
		}
	protected:
		int m;
		void getm()
		{
			cout<<"In getm(),Enter value of m:";
			cin>>m;
		}
};
main()
{
	access a;
	a.h=4;
	a.geth();
}
