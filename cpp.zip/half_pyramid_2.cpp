#include<iostream>
using namespace std;
int main()
{
	int i,j,n,sp;
	cout<<"enter the number: ";
	cin>>n;
	for(i=1;i<=n;i++)
	{
		for(sp=i;sp<n;sp++)
		{
			cout<<" ";
		}
		for(j=1;j<=i;j++)
		{
			cout<<"*";
		}
		cout<<"\n";
		cout<<"\n";
	}
}
