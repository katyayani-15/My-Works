#include<iostream>
using namespace std;
int main()
{
	int a,b,c,max,min,mid;
	cout<<"enter the numbers a and b and c: ";
	cin>>a;
	cin>>b;
	cin>>c;
	max=(a>b&&a>c)?a:(b>c)?b:c;
	cout<<"big number is : "<<max<<endl;
	min=(a<b&&a<c)?a:(b<c)?b:c;
	cout<<"small number is : "<<min<<endl;
	mid=(a+b+c)-(max+min);
	cout<<"middle number is : "<<mid<<endl;
	return 0;
	
}
