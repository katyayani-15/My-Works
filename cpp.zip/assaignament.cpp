
#include<iostream>
using namespace std;
int main()
{
	int num1,num2;
	cout<<"Enter a number num1: ";
	cin>>num1;
	num2=num1;
    cout<<"num2=num1: "<<num2<<endl;
    num2+=num1;
    cout<<"num2=num2+num1: "<<num2<<endl;
    num2-=num1;
    cout<<"num2=num2-num1: "<<num2<<endl;
    num2*=num1;
    cout<<"num2=num2*num1: "<<num2<<endl;
    num2/=num1;
    cout<<"num2=num2/num1: "<<num2<<endl;
    return 0;
}

