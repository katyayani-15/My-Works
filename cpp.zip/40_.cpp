#include <iostream>
using namespace std;
int main()
{
    int num1,num2;
   	cout<<"Name:M.KATYAYANI"<<endl;
    cout<<"ID:S170464"<<endl;
    cout<<"Class:CSE-1D"<<endl;
    cout << "Enter two integers: ";
    cin >> num1>>num2;
    cout << "You entered integers " << num1<<","<<num2;
    return 0;
}

