#include<iostream>
using namespace std;
int main()
{
	int num,rem,sum=0,n;
	cout<<"enter the number: ";
	cin>>num;
	n=num;
	while(num>0)
	{
		rem=num%10;
		sum=rem+sum*10;
		num=num/10;
	}
	if(sum==n)
	{
		cout<<""<<n<<" is a pallindrome";
	}
	else
	{
		cout<<""<<n<<" is not a pallindrome";
	}
	return 0;
}
