#include<iostream>
using namespace std;

class A
{
 private :
 int j;
 int k;

 public :
 virtual void show ( ) { cout <<endl<<"In A class"; }

};

class B
{
 private :
 int j;
public :
 void show( ) { cout <<endl<<"in B class"; }
};

class C
{
 public :
 void show( ) { cout <<endl<<"In C class"; }
};

int main( )
{

 A X;
 B y;
 C z;

 cout <<endl<<"Size of x = "<<sizeof (X);
 cout <<endl<<"Size of y = "<<sizeof (y);
 cout <<endl<<"Size of z = "<<sizeof (z);
}
