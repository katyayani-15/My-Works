#include<stdio.h>
void merge_divide(int a[],int first,int last)
{
    int mid;
    if(first<last)
    {
        mid=(first+last)/2;
        merge_divide(a,first,mid);
        merge_divide(a,mid+1,last);
        mergesort_merge(a,first,mid,last);

    }
}
void mergesort_merge(int a[],int first,int mid,int last)
{
    int temp[200],index,i,j;
    i=first;
    j=mid+1;
    index=first;
    while(i<=mid&&j<=last)
    {
        if(a[i]<a[j])
        {
            temp[index]=a[i];
            i++;
            index++;
        }
        else
        {
            temp[index]=a[j];
            j++;
            index++;
        }
    }
    if(i>mid)
    {
        while(j<=last)
        {
            temp[index]=a[j];
             j++;
             index++;
        }
    }
    else
    {
        while(i<=mid)
        {
            temp[index]=a[i];
            i++;
            index++;
        }
    }
    for(i=0;i<index;i++)
    {
        a[i]=temp[i];
    }
}
main()
{
     int i,n;
    int a[100];
    printf("enter number of elements:");
    scanf("%d",&n);
    printf("\nenter elements:");
    for(i=0;i<n;i++)
    {
        scanf("%d",&a[i]);
    }
    merge_divide(a,0,n-1);
    printf("insertion elements are:");
    for(i=0;i<n;i++)
    {
        printf("%d\t",a[i]);
    }
}
