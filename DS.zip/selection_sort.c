#include<stdio.h>
void selection(int a[],int n)
{
    int i,j,min,temp;
    for(i=0;i<n;i++)
    {
        min=i;
        for(j=i+1;j<n;j++)
        {
         if(a[j]<a[min])
         {
             min=j;
         }
        }
        temp=a[min];
        a[min]=a[i];
        a[i]=temp;
    }
}
main()
{
    int i,n;
    int a[100];
    printf("enter number of elements:");
    scanf("%d",&n);
    printf("\nenter elements:");
    for(i=0;i<n;i++)
    {
        scanf("%d",&a[i]);
    }
    selection(a,n);
    printf("insertion elements are:");
    for(i=0;i<n;i++)
    {
        printf("%d\t",a[i]);
    }
}
