#include<stdio.h>
#include<stdlib.h>
struct node
{
    int data;
    struct node *link;
};
struct node *root;
void append()
{
    struct node *temp,*k;
    temp=(struct node*)malloc(sizeof(struct node));
    printf("enter the data:");
    scanf("%d",&temp->data);
    temp->link=NULL;
    if(root==NULL)
    {
        root=temp;
        temp->link=root;

    }
    else
    {
        k=root;
        while(k->link!=root)
        {
            k=k->link;
        }
        k->link=temp;
        temp->link=root;
    }
}
void addbegin()
{
    struct node *temp,*s;
    temp=(struct node*)malloc(sizeof(struct node));
    printf("enter data:");
    scanf("%d",&temp->data);
    temp->link=NULL;
    if(root==NULL)
    {
        root=temp;
        temp->link=root;
    }
    else
    {
        s=root;
        while(s->link!=root)
        {
            s=s->link;
        }
        temp->link=root;
        root=temp;
        s->link=root;

    }
}
int length()
{
    struct node *s;
    int count=1;
    s=root;
    while(s->link!=root)
    {
        count++;
        s=s->link;
    }
    return count;
}
void display()
{
    struct node *k;
    k=root;
    if(k==NULL)
    {
        printf("no nodes");
    }
    else
    {
        while(k->link!=root)
        {
            printf("%d->",k->data);
            k=k->link;
        }
        printf("%d->",k->data);
    }
}
void addatafter()
{
    struct node *s,*k;
    int loc,len=length(),i=1;
    printf("enter the location:");
    scanf("%d",&loc);
    if(loc>len)
    {
        printf("invalid location");
    }
    else
    {
        s=(struct node*)malloc(sizeof(struct node));
        printf("enter the data:");
        scanf("%d",&s->data);
        s->link=NULL;
        k=root;
        while(i<loc)
        {
            k=k->link;
            i++;
        }

        s->link=k->link;
          k->link=s;

    }
}
void delete1()
{
    struct node *temp=root,*s=root;
    int loc;
    printf("enter the location:");
    scanf("%d",&loc);
    if(loc==1)
    {
        root=s->link;
        temp->link=root;
        s->link=root;
        free(s);
    }
    else
    {
        struct node *k=root;
        int i=1;
        while(i<loc-1)
        {
            s=s->link;
            i++;
        }
        k=s->link;
        s->link=k->link;
        k->link=NULL;
        free(k);

}
}

int main()
{
    int ch,len;
    while(1)
    {
        printf("\nCircular linked list operations:\n");
        printf("1.append\n");
        printf("2.add at begin\n");
        printf("3.add at after\n");
        printf("4.length\n");
        printf("5.display\n");
        printf("6.delete\n");
        printf("7.quit\n");
        printf("enter the choice:");
        scanf("%d",&ch);
        switch(ch)
        {
            case 1:append();
            break;
            case 2:addbegin();
            break;
            case 3:addatafter();
            break;
            case 4:len=length();
            printf("%d",len);
            break;
            case 5:display();
            break;
            case 6:delete1();
            break;
            case 7:exit(1);
            break;
            default:printf("invalid choice\n");
        }
    }
}



