#include<stdio.h>
void insertion(int a[],int n)
{
    int i,j;
    int temp;
    for(i=0;i<n;i++)
    {
        temp=a[i];
        for(j=i;j>0&&a[j-1]>temp;j--)
        {
            a[j]=a[j-1];
        }
        a[j]=temp;
    }
}
main()
{
    int i,n;
    int a[100];
    printf("enter number of elements:");
    scanf("%d",&n);
    printf("\nenter elements:");
    for(i=0;i<n;i++)
    {
        scanf("%d",&a[i]);
    }
    insertion(a,n);
    printf("insertion elements are:");
    for(i=0;i<n;i++)
    {
        printf("%d\t",a[i]);
    }
}
