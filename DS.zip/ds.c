#include<stdio.h>
int main()
{
    for(; ;)
        for(; ;)
        printf("hello");
}
