
#include<stdio.h>
#include<string.h>
#define MAXSIZE 50
int stack[MAXSIZE];
char post[MAXSIZE];
int top=-1;
void pushstack(int temp);
void evaluate(char c);
void main()
{
    int i,l;
    printf("enter postfix exp:");
    gets(post);
    l=strlen(post);
    for(i=0;i<l;i++)
    {
        if(post[i]>='0'&&post[i]<='9')
        {
            pushstack(i);
        }
        if(post[i]=='+'||post[i]=='-'||post[i]=='*'||post[i]=='/'||post[i]=='^')
        {
            evaluate(post[i]);
        }

    }
    printf("\nresult:%d",stack[top]);
    getch();
}
void pushstack(int temp)
{
    top++;
    stack[top]=(int)(post[temp]-48);
}
void evaluate(char c)
{
    int a,b,ans;
    a=stack[top];
    top--;
    b=stack[top];
    top--;
    switch(c)
    {
    case '+':
        ans=b+a;
        break;
    case '-':
        ans=b-a;
        break;
    case '*':
        ans=b*a;
        break;
    case '/':
        ans=b/a;
        break;
    case '^':
        ans=b^a;
        break;
    default:
        printf("invalid input.");
        break;
    }
    top++;
    stack[top]=ans;
}
