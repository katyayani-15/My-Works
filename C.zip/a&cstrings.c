#include<stdio.h>
#include<string.h>
int main()
{
    char a[100][50];
    int count=0,i,n;
    printf("enter the number of strings:");
    scanf("%d",&n);
    for(i=0;i<n;i++)
    {
        printf("enter a string:");
        scanf("%s",a[i]);
    }
    printf("enter strings starting with a and c are:");
    for(i=0;i<n;i++)
    {
        if(a[i][0]=='a' || a[i][0]=='c')
        {
            puts(a[i]);
            count++;
        }
    }
    if(count==0)
        printf("no string found staring with a and c");
}
