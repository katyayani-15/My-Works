#include<stdio.h>
int main()
{
    int a,b,c,d;
    printf("enter the value of a ,c\n");
    scanf("%d%d",&a,&c);
    a=a;
    b=a++;
    c=c;
    d=++c;
    printf("%d\n%d\n%d\n%d",a,b,c,d);

}
