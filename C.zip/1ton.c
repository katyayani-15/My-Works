#include<stdio.h>
void display(int,int);
void p(int);
int main()
{
  int i=1,n;
  printf("the upper limit:");
  scanf("%d",&n);
  printf("enter the numbers from i to n:");
  display(i,n);
  printf("enter the numbers from n to i:");
  p(n);
}
void display(int i,int n)
{
    if(i==n+1)
    {
        return ;
    }
    else
    {
        printf("%d\n",i);
       display(i+1,n);
    }
}
void p(int n)
{
    if(n==0)
    {
        return ;
    }
    else
    {
        printf("%d\n",n);
        p(n-1);
    }
}
