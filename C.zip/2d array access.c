#include<stdio.h>
main()
{
    int i,j,a[10][10],n,m;
    printf("enter the size of the matrix:");
    scanf("%d\n%d",&n,&m);
    printf("enter the elements:\n");
    for(i=0;i<n;i++)
    {
        for(j=0;j<m;j++)
        {
            scanf("%d\n",&a[i][j]);
        }
    }
    for(i=0;i<n;i++)
    {
        for(j=0;j<m;j++)
        {
            printf("%d ",a[i][j]);
        }
           printf("\n");

    }
}
