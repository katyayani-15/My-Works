#include<stdio.h>
main()
{
    int y;
    printf("M.KATYAYANI\nID NO:S170464\n");
    printf("enter the year:");
    scanf("%d",&y);
    if(y%4==0)
    {
        printf("it is a leap year");
    }
    else
    {
        printf("it is not a leap year");
    }
}
