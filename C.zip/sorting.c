#include<stdio.h>
#include<string.h>
int main()
{
    int i,j,n;
    char a[20],temp;
    printf("enter the sting:");
    gets(a);
    n=strlen(a);
    for(i=0;i<n;i++)
    {
        for(j=i+1;j<n;j++)
        {
            if(a[i]>a[j])//ascending order
            {
                temp=a[i];
                a[i]=a[j];
                a[j]=temp;
            }
        }
    }
    printf("sorted string:%s",a);

}
