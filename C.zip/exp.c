#include<stdio.h>
int num(int,int);
int main()
{
    int num1,num2,r;
    printf("enter the number:");
    scanf("%d%d",&num1,&num2);
    r=num(num1,num2);
    printf("%d is the result",r);
}
int num(int x,int y)
{
    if(y==1)
    {
        return 1;
    }
    else
    {
        return x*num(x,y-1);
    }
}
