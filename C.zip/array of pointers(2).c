#include<stdio.h>
main()
{
    int a=4,b=3,c=23,d=87;
    int *p,*q,*i,*s;
    int *pt[4];
    p=&a;
    q=&b;
    i=&c;
    s=&d;
    printf("%d\n",*p);
    printf("%d\n",*q);
    printf("%d\n",*i);
    printf("%d",*s);
}
