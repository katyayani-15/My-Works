#include<stdio.h>
int main()
{
    int b[100],max,min,i,n;
    printf("enter the size of the array:");
    scanf("%d",&n);
    printf("enter the elements:\n");
    for(i=0;i<n;i++)
    {
        scanf("%d",&b[i]);
    }
    max=b[0];
    min=b[0];
    for(i=0;i<n;i++)
    {
        if(b[i]>max)
        {
            max=b[i];
        }
        if(b[i]<min)
        {
            min=b[i];
        }
    }
    printf("maximum element is:%d\n",max);
    printf("minimum element is:%d",min);

}
