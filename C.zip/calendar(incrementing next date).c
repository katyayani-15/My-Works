#include<stdio.h>
int main()
{
    int D,M,Y;
    printf("enter the date,month and year:");
    scanf("%d%d%d",&D,&M,&Y);
    printf("%d-%d-%d",D,M,Y);
    if(D)

}
