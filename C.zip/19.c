#include<stdio.h>
void main()
{
	int a[10],b[10],c[20],i,j;
	printf("NAME=R.JYOTSNA SRIVALLI\n");
	printf("ID NO=S170429\n");
	printf("Enter the elements into the array 'A':\n");
	for(i=0;i<10;i++)
	{
        scanf("%d",&a[i]);
	}
	printf("Enter the elements into the array 'B':\n");
	for(i=0;i<10;i++)
	{
		scanf("%d",&b[i]);
	}
	for(i=0;i<10;i++)
	{
		c[i]=a[i];
	}
	for(i=0;i<20;i++)
	{
			c[10+i]=b[i];

	}
	printf("\nThe concatenated array is:\n");
	for(i=0;i<20;i++)
	{
		printf("%d  ",c[i]);
	}
}


