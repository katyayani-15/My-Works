#include <stdio.h>
int main()
{
 int r,c,i,j;
  printf("M.KATYAYANI\nID NO:S170464\n");
 printf("Enter number of rows: ");
 scanf("%d", &r);
 printf("Enter number of columns: ");
 scanf("%d", &c);
 for(i=1; i<=r; i++)
 {
 for(j=1; j<=c; j++)
 {
 if(i==1 || i==r || j==1 || j==c)
 {
 printf("1");
 }
 else
 {
 printf("0");
 }
 }
 printf("\n");
 }
 return 0;
}

