#include<stdio.h>
union unionlab
{
    char name;
    float salary;
    int workers;
}ulab;
struct structlab
{
    char name[32];
    float salary;
    int workers;


}slab;
int main()
{
    printf("size of union:%d bytes",sizeof(ulab));
      printf("\nsize of structure:%d bytes",sizeof(slab));
}
