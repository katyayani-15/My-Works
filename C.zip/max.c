#include<stdio.h>
int main()
{
    int a[6],i,max;
    printf("enter the elements of array:\n");
    max=a[0];
    for(i=1;i<6;i++)
    {
        scanf("%d",&a[i]);
        if(a[i]>max)
        {
            max=a[i];
        }

    }
    printf("maximum number is %d",max);
}
