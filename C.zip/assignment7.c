#include<stdio.h>
int main()
{
    int a,b,c;
     printf("M.KATYAYANI\nID NO:S170464\n");
    printf("enter the sides of the triangle:");
    scanf("%d %d %d",&a,&b,&c);
    if(a==b&&b==c)
    {
        printf("equilateral triangle");

    }
    else if(a==b&&b!=c&&a!=c||b==c&&b!=a&&c!=a||c==a&&c!=b&&a!=b)
    {
        printf("isoceles triangle");
    }
    else if (c*c==a*a+b*b||a*a==b*b+c*c||b*b==c*c+a*a)
    {
        printf("right angled triangle");
    }
    else
    {
        printf("scalene triangle");
    }


}
