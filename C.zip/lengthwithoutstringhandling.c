#include<stdio.h>
int stringlen(char s[20]);
int main()
{
    char s[20];
    int length;
    printf("enter the string:");
    gets(s);
    length=stringlen(s);
    printf("string length is :%d",length);
}
int stringlen(char s[20])
{
    int i,c=0;
    for(i=0;s[i]!='\0';i++)
    {
        c++;
    }
    return c;
}
