#include<stdio.h>
int main()
{
    int rows,i,j,num;
    printf("enter the no of rows:");
    scanf("%d",&rows);
    num=1;
    for(i=0;i<=rows;i++)
    {
        for(j=0;j<=i;j++)
        {
            printf("%d\t",num);
            ++num;
        }
        printf("\n");
    }
}
