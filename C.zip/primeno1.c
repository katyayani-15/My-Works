#include<stdio.h>
#include<math.h>
main()
{
    int n,i,k;
    printf("enter the number:");
    scanf("%d",&n);
    if(n==2)
    {
        printf("the given number is prime");
    }
    else
    {
        for(i=3;i<=sqrt(n);i=i+2)
        {
            if(n%i==0)
            {
                printf("%d is not a prime number");
            }
            else
            {
                printf("%d is a prime number");
            }
        }


    }
}
