#include<stdio.h>
void add(int,int);
main()
{
    int m1,m2;
    printf("enter the values of m1 and m2: ");
    scanf("%d%d",&m1,&m2);
    add(m1,m2);
}
void add(int x,int y)
{
    printf("sum=%d",x+y);

}
