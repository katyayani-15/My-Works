#include<stdio.h>
int main()
{
    int rows,i,j,k;
    printf("enter the no of rows:");
    scanf("%d",&rows);
    for(i=0;i<=rows;i++)
    {
        for(j=0;j<=rows;j++)
        {
            printf(" ");
        }
        for(k=1;k<=2*i-1;k++)
        {
            printf("*");
        }
        printf("\n");
    }

for(i=1;i<=rows;i++)
{
    for(j=rows;j<=i;j++)
    {
        printf("*");
    }
    printf("\n");
}
}
