#include<stdio.h>
int main()
{
    int n,a;
    printf("enter the value of n\n");
    scanf("%d",&n);
    a=(n*(n+1))/2;
    printf("the sum of %d is %d",n,a);
}
