#include <stdio.h>
#include <math.h>
int main()
{
    int num,d;
    float e;
    printf("Enter an integer number: ");
    scanf("%d",&num);
    e=sqrt((double)num);
    d=e;
    if(d==e)
        printf("%d is a perfect square.",num);
    else
        printf("%d is not a perfect square.",num);
    return 0;
}


