#include<stdio.h>
char stringcat(char s1[],char s2[]);
main()
{
    char str1[30],str2[20];
    printf("enter the string1:");
    gets(str1);
    printf("enter the string2:");
    gets(str2);
    stringcat(str1,str2);
    printf("enter the string after concatenation:%s",str1);
}
char stringcat(char st1[30],char st2[20])
{
    int i=0,j=0;
    while(st1[i]!='\0')
    {
        i++;
    }
    while(st2[j]!='\0')
    {
        st1[i]=st2[j];
        i++;
        j++;
    }
    st1[i]='\0';
    return st1[30];
}
