#include<stdio.h>
main()
{
    int n,r,s=0;
    printf("M.KATYAYANI\nID NO:S170464\n");
    printf("enter the number:");
    scanf("%d",&n);
    while(n!=0)
    {
        r=n%10;
        s=s+r;
        n=n/10;
    }
    printf("sum of all digits:%d",s);

}
