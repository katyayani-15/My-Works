#include<stdio.h>
int hcf(int, int);
main()
{
    int res,lower,upper,i,j;
    printf("enter the values:");
    scanf("%d%d",&lower,&upper);
    res=hcf(lower,upper);
    printf("gcd is:%d\n",res);
    for(i=lower;i<=upper;i++)
    {
      for(j=i+1;j<=upper;j++)
     {if(res==1)
     {
        printf("%d,%d",i,j);
        printf("%d,%d",j,i);
     }
}
int hcf(int a,int b)
{
       if(b!=0)
        return hcf(b,a%b);
    else
        return a;

}

