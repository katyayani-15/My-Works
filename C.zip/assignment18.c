#include<stdio.h>
int duplicates(int arr[],int size)
{
 int counter=0;
 int max=0;
 int index_max=0;
 int i,j;
 for(i=0;i<size;i++)
 {
 counter=0;
 for(j=0;j<size;j++)
 {
 if(arr[i]==arr[j])
 counter++;

 }
 if(counter>max)
 {
 max=counter;
 index_max=i;

 }

 }
 return arr[index_max];
}
int main(void)
{
 int arr[]={3,2,5,1,2,3};
 printf("M.KATYAYANI\nID NO:S170464\n");
 printf("3,2,5,1,2,3");
 printf("\nmax duplicated=%d",duplicates(arr,6));
 return 0;
}
