#include<stdio.h>
void modify(int*,int);
main()
{
    int a[100],n,i;
    printf("\nenter the elements:");
    scanf("%d",&n);
    for(i=0;i<n;i++)
    {
        printf("\nenter the elements:");
        scanf("%d",&a[i]);
    }
    for(i=0;i<n;i++)
    {
        printf("\nbefore modification the elements are:%d",a[i]);
    }
    modify(a,n);
    for(i=0;i<n;i++)
    {
        printf("\nafter modification the elements are:%d",a[i]);
    }

}
void modify(int a[25],int n)
{
    a[1]=20;
    a[3]=40;
}
