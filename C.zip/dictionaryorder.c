#include<stdio.h>
#include<string.h>
int main()
{
    int i,j,n;
    char a[100][50],temp[20];
    printf("enter the no of strings:");
    scanf("%d",&n);
    printf("enter the strings one by one:");
    for(i=0;i<n;i++)
    {
        gets(a[i]);
    }
    for(i=0;i<n;i++)
    {
        for(j=i+1;j<n;j++)
        {
            if(strcmp(a[i],a[j])>0)
            {
                strcpy(temp,a[i]);
                strcpy(a[i],a[j]);
                strcpy(a[j],temp);
            }
        }
    }
    printf("sorted stings:");
    for(i=0;i<n;i++)
    {
        puts(a[i]);
    }
}
