#include<stdio.h>
int main()
{
    int count=0,i=0;
    char st[50],*pt;
    pt=st;
    printf("enter the string:");
    scanf("%s",st);
    while(*(st+i)!='\0')
    {
        count++;
        *pt++;
        i++;
    }
    printf("enter the length of the string:%d",count);
}
