#include<stdio.h>
struct student
{
    int regid;
    char name[20];
    float cgpa;
    struct address
    {
        char village[20];
        char dist[20];
        long int phno;
    }add;
};
int main()
{
    struct student s[10];
    int n,i;
    printf("enter no of students:");
    scanf("%d",&n);
    for(i=0;i<n;i++)
    {
        printf("enter regid:");
        scanf("%d",&s[i].regid);
        printf("enter name:");
        scanf("%s",&s[i].name);
         printf("enter cgpa:");
        scanf("%f",&s[i].cgpa);
          printf("enter address-village,dist,phno:");
        scanf("%s%s%d",s[i].add.village,s[i].add.dist,&s[i].add.phno);
    }
    int t_no,topper=s[0].cgpa;
    for(i=0;i<n;i++)
    {
        if(s[i].cgpa>topper)
            {
                topper=s[i].cgpa;
                t_no=i;
            }
    }
    printf("\ntopper student details are:\n");
    printf("regid:%d\n",s[t_no].regid);
    printf("name:%s\n",s[t_no].name);
    printf("cgpa:%f\n",s[t_no].cgpa);
    printf("address:%s\n%s\n%d",s[t_no].add.village,s[t_no].add.dist,s[t_no].add.phno);
}


