#include<stdio.h>
struct student
{
    char name[30];
    int rollno;
    struct dob
    {
        int dd;
        int mm;
        int yyyy;
    }dob;
}std;
int main()
{
    struct student;
    printf("enter name:");
    scanf("%s",&std.name);
    printf("enter roll no:");
    scanf("%d",&std.rollno);
    printf("enter the date of birth:[DD MM YYYY]format:");
    scanf("%d\n%d\n%d",&std.dob.dd,&std.dob.mm,&std.dob.yyyy);
    printf("\nname:%s\nrollno:%d\ndob:%d-%d-%d",std.name,std.rollno,std.dob.dd,std.dob.mm,std.dob.yyyy);
}
