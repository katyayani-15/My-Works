#include<stdio.h>
int mul(int,int);
main()
{
    int a,b,result;
    printf("enter the numbers:");
    scanf("%d%d",&a,&b);
    result=mul(a,b);
    printf("multiplication:%d",result);
}
int mul(int x,int y)
{
    int result=0,i;
    for(i=0;i<y;i++)
    {
        result=result+x;
    }
    return result;
}
