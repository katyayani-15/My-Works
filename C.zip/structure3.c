#include<stdio.h>
#include<string.h>
struct student
{
    char sname[30];
    int sid;
    int sage;
};
struct student s;
int main()
{
    struct student s[50]={{"katyayani",20,17},{"priya",23,17}};
    int i;
    for(i=0;i<2;i++)
    {
        printf("\n%d.student details:",i+1);
        printf("\nStudent Name:%s",s[i].sname);
        printf("\nStudent id no:%d",s[i].sid);
        printf("\nstudent age:%d",s[i].sage);
    }
}
