#include<stdio.h>
int sum(int);
int main()
{
    int num,r;
    printf("enter the value:");
    scanf("%d",&num);
    r=sum(num);
    printf("sum is %d",r);
}
int sum(int n)
{
    if(n!=0)
    {
        return n+sum(n-1);
    }
    else
    {
        return 1;
    }
}
