#include<stdio.h>
void main()
{
    int a,b,c,n;
    printf("enter the values of a,b:\n");
    scanf("%d%d",&a,&b);
    printf("enter your choice c");
    scanf("%d",&n);
    switch(n)
    {
        case 1:c=a+b;
        printf("%d",c);
        break;
        case 2:c=a-b;
        printf("%d",c);break;
        case 3:c=a*b;
        printf("%d",c);break;
        case 4:c=a/b;
        printf("%d",c);break;
        default:{}
    }
}
