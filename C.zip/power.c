#include<stdio.h>
int power(int,int);
main()
{
    int base,exp,result;
    printf("enter the base and exp:");
    scanf("%d%d",&base,&exp);
    result=power(base,exp);
    printf("value=%d",result);
}
int power(int b, int e)
{
    if(e==0)
        return 1;
    else
        return b*power(b,e-1);
}
