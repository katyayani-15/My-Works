#include<stdio.h>
int add(int,int);
main()
{
    int n1,n2,result;
    printf("enter the values of n1 and n2:");
    scanf("%d %d",&n1,&n2);
    result=add(n1,n2);
    printf("sum=%d",result);
}
int add(int x,int y)
{
    return(x+y);
}
