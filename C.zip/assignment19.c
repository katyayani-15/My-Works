#include<stdio.h>
int main()
{
 int a[10],b[10],n,i;
  printf("M.KATYAYANI\nID NO:S170464\n");
 printf("enter the size of the array:\n");
 scanf("%d",&n);
 printf("enter A array elements:\n");
 for(i=0;i<n;i++)
 {
 scanf("%d",&a[i]);
 }
 printf("enter B array element: \n");
 for(i=0;i<n;i++)
 {
 scanf("%d",&b[i]);
 }
 printf("Array of C: \n");
 for(i=0;i<n;i++)
 {
 printf("%d ",a[i]);
 }
 for(i=0;i<n;i++)
 {
 printf("%d ",b[i]);
 }
}

