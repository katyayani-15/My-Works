#include<stdio.h>
int main()
{
    int i,a[5],sum=0;
    printf("enter the array elements");
    for(i=0;i<5;i++)
    {
        scanf("%d\n",&a[i]);
        sum=sum+a[i];
    }
    printf("%d",sum);
}
