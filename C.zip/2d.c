 #include<stdio.h>
 int main()
 {
     int a[20][10],i,j;
     printf("enter the elements of array:");
     for(i=0;i<4;i++)
     {
         for(j=0;j<5;j++)
         {
             scanf("%d",&a[i][j]);
         }
     }
     for(i=0;i<4;i++)
     {
         for(j=0;j<5;j++)
         {
             printf("%d",a[i][j]);
         }
     }
 }
