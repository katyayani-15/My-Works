#include<stdio.h>
#include<string.h>
struct student
{
    char *sname;// or sname[30];
    int sid;
    int sage;
};
int main()
{
   struct student s;
   s.sname="katyayani";// or strcpy(s.sname,"katyayani");
   s.sid=2332;
   s.sage=17;
printf("student name:%s\n",s.sname);
printf("student Id is:%d\n",s.sid);
printf("student age:%d",s.sage);
}
