#include<stdio.h>
main()
{
    int A,B;
    printf("M.KATYAYANI\nID NO:S170464\n");
    printf("enter the percentages of marks a student got in A and B:");
    scanf("%d%d",&A,&B);
    if(A>55&&B>45)
    {
        printf("THE STUDENT IS PASSED ");
    }
    else if(A<55&&A>=45&&B>45)
    {
        printf("THE STUDENT IS PASSED");
    }
    else if(A>65&&B<45)
    {
        printf("THE STUDENT IS ALLOWED TO REAPPEAR THE SUBJECT B");
    }
    else
    {
        printf("THE STUDENT IS FAILED");
    }
}
