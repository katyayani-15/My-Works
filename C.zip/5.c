#include<stdio.h>
main()
{
    int a[20],i,n,s;
    printf("enter the no of elements:");
    scanf("%d",&n);
    printf("sum:");
    scanf("%d",&s);
    printf("enter the elements:");
    for(i=0;i<n;i++)
    {
        scanf("%d",&a[i]);
    }
    for(i=0;i<n;i++)
            {
                if(sum==(a[i]+a[i+]||)
                printf("duplicated:%d\n",a[i]);
            }

