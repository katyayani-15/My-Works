#include<stdio.h>
#include<math.h>
#include<stdlib.h>
int divide(int,int);
int main()
{
    int a,b,result;
    printf("enter the numbers:");
    scanf("%d%d",&a,&b);
    result=divide(a,b);
    printf("quoteint:%d",result);
}
int divide(int s, int t)
{
    if(t==0)
    {
        printf("error!! divisible by 0 ");
        exit(0);
    }
    int sign=1;
    if(s*t<0)
    {
        sign =-1;
        s=abs(s),t=abs(t);
    }
    int quoteint=0;
    while(s>=t)
    {
        s=s-t;
        quoteint++;
    }
    printf("remainder is %d\n",s);
    return sign*quoteint;
}
