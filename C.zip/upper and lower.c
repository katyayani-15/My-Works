#include<stdio.h>
char stringlow(char s[]);
char stringup(char s[]);
main()
{
    char s1[100],s2[100];
    printf("enter the s1:\n");
    gets(s1);
    stringlow(s1);
    printf("string after lower:%s\n",s1);
    printf("enter the s2\n");
    gets(s2);
    stringup(s2);
    printf("string after upper:%s\n",s2);

}
char stringlow(char s1[30])
{
    int i=0;
    while(s1[i]!='\0')
    {
        if(s1[i]>='A'&&s1[i]<='Z')
        s1[i]=s1[i]+32;
        ++i;
    }
    return s1[30];

}
char stringup(char s2[30])
{

    int i=0;
    while(s2[i]!='\0')
    {
        if(s2[i]>='a'&&s2[i]<='z')
            s2[i]=s2[i]-32;
            ++i;
    }
    return s2[30];
}
