#include<stdio.h>
main()
{
    int a[100],i,n,even=0,odd=0;
     printf("M.KATYAYANI\nID NO:S170464\n");
    printf("enter the no of numbers:");
    scanf("%d",&n);
    printf("enter the numbers:");
    for(i=0;i<n;i++)
    {
      scanf("%d",&a[i]);
    }
    printf("Even numbers are:\n");
    for(i=0;i<n;i++)
    {
        if(a[i]%2==0)
        {
            printf("%d\n",a[i]);
            even=even+a[i];
              printf("
        }
    }
    printf("Odd numbers are:\n");
    for(i=0;i<n;i++)
    {
        if(a[i]%2!=0)
        {
            printf("%d\n",a[i]);
            odd=odd+a[i];
                printf("sum of odd=%d",odd);
        }
}
}
