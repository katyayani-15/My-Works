#include<stdio.h>
int fib(int);
int main()
{
    int num,i,result;
    printf("enter the no of values in the series:");
    scanf("%d",&num);
    for(i=0;i<num;i++)
{
    result=fib(i);
    printf("%d,",result);
}

}
int fib(int m)
{
    if(m==0)
    {
        return 0;
    }
    else if(m==1)
    {
            return 1;
    }
    else
    {
    return(fib(m-1)+fib(m-2));
    }
}
