  #include<stdio.h>
int main()
{
   int a[10],i,n,k,j;
   printf("enter the no of elements:");
   scanf("%d",&n);
   printf("enter the elements:");
   for(i=0;i<n;i++)
   {
       scanf("%d",);
   }
   for(i=0;i<n;i++)
   {
     for(j=i+1;j<n;j++)

     {
         if(a[i]==a[j])
         {
             for(k=j;k<n;k++)
             {
                 a[k]=a[k+1];
             }
             n--;

         }
         }
   }
         printf("enter the elements:");
         for(i=0;i<n;i++)
         {
             printf("%d\n",a[i]);
         }
   }




