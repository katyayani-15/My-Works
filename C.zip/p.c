#include<stdio.h>
int main()
{
    int a,i,j,num=0;
    printf("enter the no of rows:");
    scanf("%d",&a);
    for(i=1;i<=a;i++)
    {
        for(j=1;j<=i;j++)
        {
            num++;
            printf("%d ",num*num);
        }
        printf("\n");
    }
}
