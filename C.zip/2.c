#include<stdio.h>
int main()
{
    int n,sum,i;
    printf("enter the value of n\n");
    scanf("%d",&n);
    sum=0;
    for(i=1;i<=n;i++)
    {
        sum=sum+i;
    }
    printf("the sum of %d numbers is %d",n,sum);
}
