#include<stdio.h>
char stringupper(char str[20]);
main()
{
    char str[20];
    printf("enter the string:");
    gets(str);
    stringupper(str);
    printf("enter the string after conversion:%s",str);
}
char stringupper(char str[20])
{
    int i=0;
    while(str[i]!='\0')
    {
        str[i]=str[i]-32;
        i++;
    }
    return str[20];
}
