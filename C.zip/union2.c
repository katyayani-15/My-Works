#include<stdio.h>
#include<string.h>
union employee
{
    int eid;
    float esal;
    char ename[70];
};
int main()
{
  union employee e;
   e.eid=23;
   e.esal=40000;
    strcpy(e.ename,"Katyayani");
   printf("%d\n",e.eid);

   printf("%f\n",e.esal);

   printf("%s",e.ename);
}
