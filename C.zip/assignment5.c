#include<stdio.h>
main()
{
    int a[10],large,small,range,n,i;
     printf("M.KATYAYANI\nID NO:S170464\n");
    printf("enter the no of elements:");
    scanf("%d",&n);
    printf("enter the elements:");
    for(i=0;i<n;i++)
   {
     scanf("%d",&a[i]);
   }
   large=a[0];
   for(i=0;i<n;i++)
   {
    if(a[i]>large)
   {
   large=a[i];
   }
   }
printf("large=%d\n",large);
small=a[0];
 for(i=0;i<n;i++)
 {
 if(a[i]<small)
{
small=a[i];
 }
 }
 printf("small=%d\n",small);
 printf("range=%d",large-small);
}



