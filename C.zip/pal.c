#include<stdio.h>
int main()
{
    int n,r;
    r=0;
    printf("enter the value of");
    scanf("%d",&n);
    while(n!=0)
    {
        r=r*10;
        r=r+n%10;
        n=n/10;
    }
        printf("reversed number %d",r);
}
