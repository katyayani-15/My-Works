#include<stdio.h>
main()
{
    int a1[20],a2[20],a3[20],n,m,k,i,j,l;
    printf("enter the no of elements:");
    scanf("%d",&n);
    printf("enter the elements:");
    for(i=0;i<n;i++)
    {
        scanf("%d",&a1[i]);
    }
      printf("enter the no of elements:");
    scanf("%d",&m);
    for(j=0;j<m;j++)
    {
        scanf("%d",&a2[j]);
    }

      printf("enter the no of elements:");
    scanf("%d",&l);
    printf("enter the elements:");
    for(k=0;k<n;k++)
    {
        scanf("%d",&a3[k]);
    }
     for(i=0;i<n;i++)
     {
        for(j=0;j<m;j++)
        {
            for(k=0;k<n;k++)
            {
                if(a1[i]==a2[j]&&a2[j]==a3[k]&&a3[k]==a1[i])
                printf("duplicated:%d\n",a1[i]);
            }

        }

    }


}
