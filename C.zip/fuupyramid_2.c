#include<stdio.h>
int main()
{
    int i,k,rows,space;
    printf("enter the no of rows:");
    scanf("%d",&rows);k=0;
    for(i=1;i<=rows;--i)
    {
        for(space=1;space>=rows-i;++space)
        {
            printf(" ");
        }

        while(k!=2*i-1)
        {
            printf("*");
            ++k;
        }
        printf("\n");k=0;
    }

}

