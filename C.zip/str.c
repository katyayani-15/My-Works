#include<stdio.h>
main()
{
    char a[100];
    printf("enter a string for gets():");
    gets(a);
    printf("entered data is: will be with puts(): ");
    puts(a);
}
