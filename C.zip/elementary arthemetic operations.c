#include<stdio.h>
#include<stdlib.h>
main()
{
    int a,b,p,i=1;
      a=rand()%10;
      b=rand()%10;
      printf("%d",a);
      printf("%d",b);
      p=rand()%3;
      //if(p==1)
      //{
        //  c=a+b;
          //scanf("%d",&c);
          //printf("%d+%d=",a,b);

      //}



}
