#include<stdio.h>
int main()
{
    int a[5],i,sum,p;
    printf("enter the elements:");
    for(i=0;i<5;i++)
    {
        printf("enter a[%d]:",i);
        scanf("%d",&a[i]);
    }
    sum=0;
    p=1;
    for(i=0;i<5;i++)
    {
        sum=sum+a[i];
        p=p*a[i];
    }
    printf("sum=%d  ",sum);
    printf("product=%d",p);
}
