#include<stdio.h>
int main()
{
    float mean;
    int sum,i,n=5,a[]={2,6,7,8,9};
    sum=0;
    for(i=0;i<n;i++)
    {
        sum=+a[i];
    }
    printf("mean=%f",sum/(float)n);
}
