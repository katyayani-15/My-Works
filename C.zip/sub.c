#include<stdio.h>
#include<string.h>
main()
{
    char str,substr;
    printf("enter the string:");
    scanf("%c",&str);
    substr(str,2,4);
    printf("%c",substr);
}
