#include<stdio.h>
union car
{
    char name[60];
    int price;
};
main()
{
    union car c={"BMW",30000000};
    printf("%s\n%d",c.name,c.price);

}
