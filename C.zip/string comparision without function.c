#include<stdio.h>
int stringcmp(char s1[],char s2[]);
main()
{
    char str1[20],str2[20];
    printf("enter string1:");
    gets(str1);
    printf("enter string2:");
    gets(str2);
    if(stringcmp(str1,str2)==0)
    {
        printf("strings are same");
    }
    else
    {
        printf("strings are not same");
    }
}
int stringcmp(char s1[20],char s2[10])
{
    int i=0;
    while(s1[i]!='\0')
    {
        if(s1[i]!=s2[i])
        {
        return 1;
        }
    }
    return 0;



}
