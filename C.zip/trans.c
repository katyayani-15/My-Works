#include<stdio.h>
int main()
{
    int i,j,a[10][10],b[10][10],m,n;
    printf("enter the size of matrix:\n");
    scanf("%d\n%d",&n,&m);
    printf("enter the elements of the matrix:");
    for(i=0;i<n;i++)
    {
        for(j=0;j<m;j++)
        {
            scanf("%d\n",&a[i][j]);
        }
    }
    printf("the given matrix is:\n");
    for(i=0;i<n;i++)
    {
        for(j=0;j<m;j++)
        {
            printf("%d",a[i][j]);

        }
         printf("\n");
    }
    printf("the transpose of the given matrix:\n");
    for(i=0;i<m;i++)
    {
        for(j=0;j<n;j++)
        {
            b[i][j]=a[j][i];
          printf("%d",b[i][j]);
        }

          printf("\n");
    }
}





