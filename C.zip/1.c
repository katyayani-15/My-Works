#include<stdio.h>
int small(int a[20],int a[20]);
main()
{
    int s,i,n;
    int a[20];
    printf("enter the number of elements:\n");
    scanf("%d",&n);
    printf("enter the elements:");
    for(i=0;i<n;i++)
    {
       scanf("%d",a[i]);
    }
    s=small(a[30]);
    printf("small number:%d",s);
}
int small(int a[20],int a[20])
{
    int i,n;
    for(i=0;i<n;i++)
    {
        if(a[i]>a[i+1])
        {
            return a[i+1];
        }
        else
        {
            return(small(a[i]));
        }
    }
}
