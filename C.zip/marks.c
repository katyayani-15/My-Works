#include<stdio.h>
float main()
{
    float marks;
    printf("enter the marks\n");
    scanf("%f",&marks);
    if(marks>=9)
    {
        printf("A grade");
    }
    else if(marks=7)
    {
        printf("B grade");
    }
    else
    {
        printf("fail");
    }

}
