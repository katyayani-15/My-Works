#include<stdio.h>
int main()
{
 int i=1,c=0,n;
 printf("M.KATYAYANI\nID NO:S170464\n");
 printf("enter the number:");
 scanf("%d",&n);
 printf("The numbers from 1 to n which are not divisible by 3 & 5 are:\n");
 for(i=1;i<=n;i++)
 {
 if((i%3!=0)&&(i%5!=0))
 {
 printf("%d\t",i);
 c++;
 }
 }
 printf("\n\nTotal Count = %d",c);
 return 0;
}

