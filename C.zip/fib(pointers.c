#include<stdio.h>
int main()
{
    int a=0,b=1,c,*p,*q,*r;
    p=&a;
    q=&b;
    r=&c;
    int n,i;
    printf("enter the no of elements:");
    scanf("%d",&n);
    printf("fibnocci series:");
    for(i=0;i<n;i++)
    {
        printf("%d\t",*p);
        *r=*p+*q;
        *p=*q;
        *q=*r;
    }
}

