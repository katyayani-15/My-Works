#include<stdio.h>
#include<stdlib.h>
main()
{
    int *a,n,i;
    printf("enter the value:\n");
    scanf("%d",&n);
    a=(int*)malloc(n*sizeof(int));
     printf("enter the values:\n");
    for(i=0;i<n;i++)
    {
        scanf("%d",a+i);
    }
    for(i=0;i<n;i++)
    {
        printf("%d\n",*(a+i));
    }

}
