#include<stdio.h>
int main()
{
    int w;
    printf("enter the value of w");
    scanf("%d",&w);
    if(w>0)
        printf("%d is positive number",w);
    else if(w==0)
        printf("%d is zero",w);
    else
        printf("%d is negative number",w);
}
