#include<stdio.h>
int main()
{
    int u,v,w;
    printf("enter u and v values\n");
    scanf("%d%d",&u,&v);
    w=u;
    u=v;
    v=w;
    printf("after swapping u and v are %d,%d",u,v);

}
