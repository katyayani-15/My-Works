#include<stdio.h>
int main()
{
    int a,j,flag;
    printf("enter the value of a:");
    scanf("%d",&a);
    flag=0;
    for(j=2;j<=a/2;j++)
    {
        if(a%j==0)
        {
            flag=1;
            break;
        }
    }
        if(flag==1)
        {
            printf("the given number is a composite number",a);
        }
        else
        {
            printf("%the given number is a prime number",a);
        }
}
