#include<stdio.h>
#include<string.h>
main()
{
    char a[10][10];
    int i,row;
    printf("enter the no of rows:");
    scanf("%d",&row);
    printf("enter the elements:");
    for(i=0;i<row;i++)
    {
        scanf("%s",a[i]);
    }
    for(i=0;i<row;i++)
    {
        printf("%s\n",a[i]);
    }
}
