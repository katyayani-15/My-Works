#include<stdio.h>
void stringlwr(char s[20]);
void stringupr(char s[20]);
int main()
{
    char s[10];
    printf("enter the string:");
    gets(s);
    stringlwr(s);
    printf("enter the strng in lower case:%s\n",s);
    stringupr(s);
    printf("enter the string in upper case:%s",s);
}
void stringlwr(char s[20])
{
    int i;
    for(i=0;s[i]!='\0';i++)
    {
        if(s[i]>='A'&&s[i]<='Z')
        {
            s[i]=s[i]+32;
        }
    }
}
void stringupr(char s[20])
{
    int i;
    for(i=0;s[i]!='\0';i++)
    {
        if(s[i]>='a'&&s[i]<='z')
        {
            s[i]=s[i]-32;
        }
    }
}
