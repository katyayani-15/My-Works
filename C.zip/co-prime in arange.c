#include<stdio.h>
int gcd(int,int);
int i,j;
main()
{
    int a,b,res;
    printf("enter the values of a and b:");
    scanf("%d%d",&a,&b);
    res=gcd(i,j);
    if(res==1)
        {
           printf("%d\n%d are co-primes",i,j);
        }
        else
        {
            printf("%d\n%d are not co-primes",i,j);
        }



}
int gcd(int p,int q)
{
    while(p!=q)
    {
        for(i=p;i<q;i++)
      {
        for(j=i+1;j<q;j++)
         {
             if(p>q)
        {
            return gcd(p-q,q);
        }
        else
        {
            return gcd(p,q-p);
        }
         }
      }
    }
    return p;
}


