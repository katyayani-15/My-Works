#include <stdio.h>
void main()
{
 float x,s,no_row;
 int i,n;
  printf("M.KATYAYANI\nID NO:S170464\n");
 printf("Input the value of x :");
 scanf("%f",&x);
 printf("Input number of terms : ");
 scanf("%d",&n);
 s =1; no_row = 1;
 for (i=1;i<n;i++)
 {
 no_row = no_row*x/(float)i;
 s=s+ no_row;
 }
 printf("\nThe sum is : %f\n",s);
}

