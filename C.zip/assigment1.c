#include<stdio.h>
main()
{
    long int n,meter,inches,feets,cm;
    printf("M.KATYAYANI\nID NO:S170464\n");
    printf("enter the distance between two cities:");
    scanf("%uld",&n);
    meter=n*1000;
    inches=n*39370.1;
    feets=n*3280.84;
    cm=n*100000;
    printf("meters:%ld\n",meter);
    printf("inches:%ld\n",inches);
    printf("feets:%ld\n",feets);
    printf("centimeters:%ld\n",cm);

}
