#include<stdio.h>
main()
{
    int a,b,c,product;
    printf("M.KATYAYANI\nID NO:S170464\n");
    printf("enter the elements:");
    scanf("%d %d %d",&a,&b,&c);
    if(a>b&&a>c)
    {
      printf("max=%d\n",a);
    }
    else if(b>c)
    {
        printf("max=%d\n",b);
    }
    else
    {
        printf("max=%d\n",c);
    }
     if(a<b&&a<c)
    {
      printf("min=%d\n",a);
    }
    else if(b<c)
    {
        printf("min=%d\n",b);
    }
    else
    {
        printf("min=%d\n",c);
    }
    if(a>b&&b>c)
    {
      printf("mid=%d\n",a);
    }
    else if(b<c)
    {
        printf("mid=%d\n",b);
    }
    else
    {
        printf("mid=%d\n",c);
    }
    product=a*b*c;
    printf("product=%d",product);
}
