#include<stdio.h>
main()
{
	int a[10],n,sum=0,i;
    printf("M.KATYAYANI\nID NO:S170464\n");
	printf("Enter n value:");
	scanf("%d",&n);
	printf("Enter elementds:\n");
	for(i=0;i<n;i++)
	{
	    scanf("%d",&a[i]);
	}
	printf("After sum array is:\n");
	for(i=0;i<n;i++)
	{
		sum=a[i];
		a[i+1]=sum+a[i+1];
		printf("%d\n",a[i]);
	}
	return 0;
}
