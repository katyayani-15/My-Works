#include<stdio.h>
int main()
{
    int a,i,j,k;
    printf("enter the number:");
    scanf("%d",&a);
    printf("prime numbers are:");
    for(i=0;i<=a;i++)
    {
        k=0;
        for(j=1;j<=a;j++)
        {
            if(i%j==0)
                k++;
        }
        if(k==2)
            printf("%d,",i);
    }
}
