#include<stdio.h>
int strlength(char s[30]);
int main()
{
    char str[30];
    int len;
    printf("enter any string:");
    gets(str);
    len=strlength(str);
    printf("enter the length of the string:%d",len);
}
int strlength(char a[30])
{
    int i=0;
    while(a[i]!='\0')
    {
        i++;
    }

    return i;
}
