#include<stdio.h>
#include<string.h>
main()
{
    char a[10],b[10];
    int c;
    printf("enter the strings:");
    scanf("%s%s",a,b);
    c=strcmp(a,b);
    printf("enter the value after comparing two strings:%d",c);
}
