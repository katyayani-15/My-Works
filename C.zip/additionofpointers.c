#include<stdio.h>
int main()
{
    int a=3,b=5;
    int *p=&a,*q=&b;
    printf("%d",&a-&b);

}
