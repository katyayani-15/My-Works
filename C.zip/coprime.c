#include<stdio.h>
int gcd(int,int);
main()
{
    int a,b,res;
    printf("enter the values of a and b:");
    scanf("%d%d",&a,&b);
    res=gcd(a,b);
    {
      if(res==1)
        {
           printf("%d\n%d are co-primes",a,b);
        }
        else
        {
            printf("%d\n%d are not co-primes",a,b);
        }
    }
}
int gcd(int p,int q)
{
    while(p!=q)
    {
        if(p>q)
        {
            return gcd(p-q,q);
        }
        else
        {
            return gcd(p,q-p);
        }
    }
    return p;
}


