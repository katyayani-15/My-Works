#include<stdio.h>
int main()
{
    int n,i,k=0;
    printf("enter the value of n:");
    scanf("%d",&n);
    for(i=2;i<=n/2;i++)
    {
        if(n%i==0)
        {
            k=1;
            break;
        }
    }
    if(k==1)
    {
        printf("%d is a composite number",n);
    }
    else
    {
        printf("%d is a prime number",n);
    }
}
