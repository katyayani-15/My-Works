#include<stdio.h>
main()
{
    printf("hi compiler");
}
