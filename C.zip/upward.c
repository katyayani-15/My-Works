#include<stdio.h>
main()
{
    int result;
    int add();
    result=add();
    printf("sum=%d",result);
}
int add()
{
    int a,b;
    printf("enter the values of a and b:");
    scanf("%d %d",&a,&b);
    return(a+b);
}
