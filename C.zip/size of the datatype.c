#include<stdio.h>
main()
{
    int a=56;
    char ch='t';
    float f=6.77;
    printf("memory alloted to integer:%d\n",sizeof(a));
    printf("memory alloted to character:%d\n",sizeof(ch));
    printf("memory alloted to float:%d\n",sizeof(f));

}
