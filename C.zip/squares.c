#include<stdio.h>
int main()
{
    int n,e;
    printf("enter the value of n\n");
    scanf("%d",&n);
    e=[n*n+1*2n+1]/6;
    printf("the sum of squares of %d is %d",n,e);

}




