#include<stdio.h>
int main(int argc,char *argv[])
{
    printf("%d",argc);
    printf("%s",argv[0]);
}
   