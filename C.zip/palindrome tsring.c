#include<stdio.h>
#include<string.h>
int main()
{
    int i=0,j;
    char s[10];
    printf("enter the string:");
    gets(s);
    j=strlen(s)-1;
    while(i<=strlen(s)/2)
    {
        if(s[i]==s[j])
        {
            i++;
            j--;
        }
        else
        {
            break;
        }
    }
    if(i>j)
    {
        printf("the string is palindrome");
    }
    else
    {
        printf("the string is not palindrome");
    }

}
