#include <stdio.h>
void main()
{
	float sum,term;
	int i,n;
    printf("M.KATYAYANI\nID NO:S170464\n");
	printf("Enter number of terms upto which series is to be computed:");
	scanf("%d",&n);
	sum=1;term=1;
	for(i=1;i<n;i++)
	{
	  term=term/i;
	  sum=sum+term;
	}
	printf("The sum upto %d terms is %f",n,sum);
}

