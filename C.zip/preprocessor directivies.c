#include<stdio.h>
#define PI 3.142
#define Number 10
main()
{
    double A,C;
    int r;
    printf("enter the radius:");
    scanf("%d",&r);
    A=PI*r*r;
    printf("enter the area of the circle:%lf\n",A);
    C=2*PI*Number;
    printf("enter the circumference of the circle:%lf",C);
}
