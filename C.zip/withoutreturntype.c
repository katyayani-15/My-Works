#include<stdio.h>
int sum(int a, int b);
main()
{
    int a,b,result;
    printf("enter the values of a and b:");
    scanf("%d%d",&a,&b);
    printf("hi\n");
    result=sum(a,b);
    printf("%d\n",result);
    printf("hello");
}
int sum(int a, int b)
{
    return a+b;
}
