#include<stdio.h>
void addone(int *point)
{
    (*point)++;
}
main()
{
    int *p,y=9;
    p=&y;
    addone(p);
    printf("%d",*p);
}
