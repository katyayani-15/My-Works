#include<stdio.h>
#include<string.h>
main()
{
    char a[10],b[20];
    printf("enter the strings:");
    scanf("%s%s",a,b);
    strcat(a,b);
    printf("added string:%s",a);
}
