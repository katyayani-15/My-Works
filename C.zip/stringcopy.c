#include<stdio.h>
#include<string.h>
main()
{
    char c[10],d[10];
    printf("enter the strings:");
    scanf("%s%s",c,d);
    strcpy(d,c);
    printf("enter the copied string:%s",d);

}
