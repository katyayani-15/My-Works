#include<stdio.h>
int sum(int x,int y)
{

    x=20;
    y=40;

}
main()
{
    int a=30,b=50;
    sum(a,b);
    printf("%d\n%d",a,b);

}
