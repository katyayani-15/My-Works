#include<stdio.h>
char strcopy(char s1[],char s2[]);
main()
{
    char st1[20],st2[20];
    printf("enter string1:");
    gets(st1);
    strcopy(st2,st1);
    printf("copied string:%s",st2);
}
char strcopy(char st2[20],char st1[20])
{
    int i=0;
    while(st1[i]!='\0')
    {
    st2[i]=st1[i];
        i++;
    }
    st2[i]='\0';
    return st2[20];
}
