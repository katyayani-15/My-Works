#include<stdio.h>
main()
{
   char ch;
   int n;
   float m;
   printf("enter a character ch:");
   scanf("%c",&ch);

   printf("enter the value of n:");
   scanf("%d",&n);

   printf("enter the value of m");
   scanf("%f",&m);

   pritnf("value of character %c\n",ch);
   printf("value of integer %d\n",n);
   printf("value of float %f\n",m);



}
