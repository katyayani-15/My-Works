#include<stdio.h>
main()
{
    int a=23,b=78,c=98,d=67,*q[4],i;
      q[0]=&a;
      q[1]=&b;
      q[2]=&c;
      q[3]=&d;
    for(i=0;i<=3;i++)
    {

    printf("the elements is=%d\n",*q[i]);
    }

}
