#include<stdio.h>
void display(int,int);
void print(int);
main()
{
    int m;
    printf("enter the value of m:");
    scanf("%d",&m);
    printf("numbers from 1 to m:\n");
    display(1,m);
    printf("numbers from m to 1:\n");
    print(m);
}
void display(int i, int n)
{
    if(i==n+1)
    {
     return;
    }
    else
    {
        printf("%d\t",i);
        display(i+1,n);
    }
}
void print(int n)
{
    if(n==0)
        return;
    else
    {
        printf("%d\t",n);
        print(n-1);
    }
}
