#include<stdio.h>
#include<string.h>
main()
{
    char a[20];
    int n;
    printf("enter the string:");
    scanf("%s",a);
    n=strlen(a);
    printf("enter the string length:%d",n);

}
