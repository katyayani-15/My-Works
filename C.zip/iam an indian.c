d#include<stdio.h>
#include<string.h>
int main()
{
    char b[100],rev[100];
    int len,i,index,ws,we;
    printf("enter a string:");
    gets(b);
    len=strlen(b);
    index=0;
    ws=len-1;
    we=len-1;
    while(ws>0)
    {
        if(b[ws]==' ')
        {
            i=ws+1;
            while(i<=we)
            {
                rev[index]=b[i];
                i++;
                index++;
            }
            rev[index++]=' ';
            we=ws-1;
        }
        ws--;
    }
    for(i=0;i<=we;i++)
    {
        rev[index]=b[i];
        index++;
    }
    rev[index]='\0';
    printf("%s",rev);
}
