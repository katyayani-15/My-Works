#include<stdio.h>
struct student
{
    int regid;
    char name[20];
    float cgpa;
    struct address
    {
        char village[20];
        char dist[20];
        long int phno;
    }add;
};
int main()
{
    struct student s[10];
    int n,i,c;
    printf("enter no of students:");
    scanf("%d",&n);
    for(i=0;i<n;i++)
    {
        printf("enter regid:");
        scanf("%d",&s[i].regid);
        printf("enter name:");
        scanf("%s",&s[i].name);
         printf("enter cgpa:");
        scanf("%f",&s[i].cgpa);
          printf("enter address-village,dist,phno:");
        scanf("%s%s%d",s[i].add.village,s[i].add.dist,&s[i].add.phno);
    }
    int j,t;
    for(i=0;i<n;i++)
    {
        for(j=0;j<n;j++)

              {
                  if(s[j].regid>s[j+1].regid)
                {
                    t=s[j].regid;
                    s[j].regid=s[j+1].regid;
                    s[j+1].regid=t;
                }
              }

    }
    for(i=0;i<n;i++)
    {
    printf("\nstudent details:\n");
    printf("regid:%d\n",s[i].regid);
    printf("name:%s\n",s[i].name);
    printf("cgpa:%f\n",s[i].cgpa);
    printf("address:%s\n%s\n%d",s[i].add.village,s[i].add.dist,s[i].add.phno);
    }
}


