#include<stdio.h>
int main()
{
    int n,a1=0,a2=1,a3,i;
    printf("enter the no of terms:");
    scanf("%d",&n);
    printf("fibanoci series:");
    for(i=0;i<=n;i++)
    {
        if(i<=1)
        {
         a3=i;
        }
        else
        {
            a3=a1+a2;
            a1=a2;
            a2=a3;
        }
            printf("%d,",a3);
    }
}
