#include<stdio.h>
int main()
{
    int n;
    printf("enter a positive number which consists of only 9 and 6 in it: ");
    scanf("%d",&n);
    int m,k,c;
    c=0;
    m=n;
    while(m!=0)//no of digits in an number
    {
        m=m/10;
        c++;

    }
    printf("no of digits in the given number:%d\n",c);
    int a[c],i,j,t;
    t=n;
    for(i=0;i<c;i++)//storing number in an array
    {
        k=t%10;
        a[i]=k;
        t=t/10;
    }
    int b=0,p;
    for(p=c-1;p>=0;p--)//changing the given number into highest number by changing at most one number
    {
        if(a[p]!=9)
        {
            a[p]=9;
            b++;
            if(b==1)
            {
                break;
            }

        }
    }
    int z;
    printf("output:");
    for(z=c-1;z>=0;z--)
    {
        printf("%d",a[z]);
    }
}
