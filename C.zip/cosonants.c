#include<stdio.h>
int main()
{
    char a[20];
    int con,v,d,s,i;
    con=v=d=s=0;
    printf("enter a string:");
    gets(a);
    for(i=0;a[i]!='\0';i++)
    {
        if(a[i]=='a'||a[i]=='e'||a[i]=='i'||a[i]=='o'||a[i]=='u'||a[i]=='A'||a[i]=='E'||a[i]=='I'||a[i]=='O'||a[i]=='U')
        {
            ++v;
        }
        else if(a[i]>='a'&&a[i]<='z'||a[i]>='A'&&a[i]<='Z')
        {
            ++con;
        }
        else if(a[i]>='0'&&a[i]<='9')
        {
            ++d;
        }
        else if(a[i]==' ')
        {
            ++s;
        }
    }
        printf("vowels:%d\n",v);
        printf("consonants:%d\n",con);
        printf("digits:%d\n",d);
        printf("spaces:%d\n",s);
}
