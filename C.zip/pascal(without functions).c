#include<stdio.h>
int main()
{
    int b,i,j,r,x;
    b=1;
    printf("rows you want to input:");
    scanf("%d",&r);
    printf("\npascal's triangle:\n");
    for(i=0;i<r;i++)
    {
        for(j=40-3*i;j>0;--j)
        {
            printf(" ");
        }
        for(x=0;x<=i;++x)
        {
            if((x==0)||(i==0))
            b=1;
            else
            b=(b*(i-x+1))/x;
            printf("%6d",b);
        }
        printf("\n");

    }
}

