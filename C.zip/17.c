#include<stdio.h>
void strong(int c)
{
	int a,sum=0,b,num;
	num=c;
		while(c!=0)
		{
		b=c%10;
		sum=sum+fact(b);
		c=c/10;
		}
	if(sum==num)
		printf("\n%d",sum);
	sum=0;
}

int fact(int a)
{
	int facta=1,b;
	for(b=1;b<=a;b++)
		facta=b*facta;
	return facta;
}
void main()
{
	int num,b;
	printf("NAME=R.JYOTSNA SRIVALLI\n");
	printf("ID NO=S170429\n");
	printf("Enter range:");
	scanf("%d",&num);
	printf("The strong numbers are:");
	for(b=1;b<=num;b++)
	{
		strong(b);
	}
}
