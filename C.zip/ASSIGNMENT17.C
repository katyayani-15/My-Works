#include<stdio.h>

int main()
{

  int num,i,fact,rem,s=0,input,f,l;
  printf("M.KATYAYANI\nID NO:S170464\n");

  printf("Enter the first value: ");

  scanf("%d",&f);

  printf("Enter the last value: ");

  scanf("%d",&l);

  printf("The Strong numbers in the given range are: ");

  for(num=f; num <= l; num++)
  {

      input = num;

      s=0;

      while(input>0)

      {
          i=1;

           fact=1;

           rem=input%10;

           while(i<=rem){

             fact=fact*i;

             i++;

           }

         s=s+fact;

         input=input/10;

      }

      if(s==num)

           printf("%d,",num);

  }
}


