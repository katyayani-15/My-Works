#include<stdio.h>
int main()
{
    int n,i;
    printf("value of n:");
    scanf("%d",&n);
    for(i=2;i=n/2;i++)
    if(n%i==1)
    {
        printf("prime no");
        return 0;
}
