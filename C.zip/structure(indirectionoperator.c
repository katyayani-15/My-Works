#include<stdio.h>
struct person
{
    int age;
    float weight;
};
int main()
{
    struct person *p,a;
    p=&a;
    printf("enter age:");
    scanf("%d",&p->age);
    printf("enter weight:");
    scanf("%f",&p->weight);
    printf("\n***Person Details***\n");
    printf("Age:%d\n",(*p).age);
    printf("weight:%f",(*p).weight);
}
