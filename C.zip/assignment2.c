#include <stdio.h>
main()
{
int y, leapyear, difference, total_days, day_of_week, weekday;
printf("M.KATYAYANI\nID NO:S170464\n");
printf("Enter the year:");
scanf ("%d", &y);
difference = (y%100);
leapyear = (y%100) / 4;
total_days = (difference*365) + leapyear ;
day_of_week = total_days % 7;
if (day_of_week == 0)
{
printf("The day on Jan 1st of this year is Monday");
}
else if (day_of_week ==1)
{
printf("The day on Jan 1st of this year is Tuesday");
}
else if (day_of_week == 2)
{
printf("The day on Jan 1st of this year is Wednesday");
}
else if (day_of_week == 3)
{
printf("The day on Jan 1st of this year is Thursday");
}
else if (day_of_week ==4)
{
printf("The day on Jan 1st of this year is Friday");
}
else if (day_of_week ==5)
{
printf("The day on Jan 1st of this year is Saturday");
}
else if (day_of_week ==6)
{
printf("The day on Jan 1st of this year is Sunday");
}
}


