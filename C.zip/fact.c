#include<stdio.h>
int fact(int);
int main()
{
    int number,result;
    printf("enter the value:");
    scanf("%d",&number);
    result=fact(number);
    printf("%d is the factorial",result);
}
int fact(int num)
{
    if(num!=1)
    {
        return num*fact(num-1);
    }
    else
    {
        return num;
    }
}
