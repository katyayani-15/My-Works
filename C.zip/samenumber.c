#include<stdio.h>
int fun(int);
int main()
{
    int n;
    printf("enter the value of n:");
    scanf("%d",&n);
    printf("%d",fun(n));
}
int fun(int m)
{
    if (m==1)
        return 1;
    else
        return 1+fun(m-1);
}
