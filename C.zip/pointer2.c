#include<stdio.h>
int sum(int*,int);
main()
{
    int a[100],n,i,res;
    printf("\nenter the elements:");
    scanf("%d",&n);
    for(i=0;i<n;i++)
    {
        printf("\nenter the elements:");
        scanf("%d",&a[i]);
    }
        res=sum(a,n);
        printf("the sum is :%d",res);
}
int sum(int a[20],int n)
{
    int i,res=0;
    for(i=0;i<n;i++)
    {
        res+=a[i];
    }
    return res;
}



