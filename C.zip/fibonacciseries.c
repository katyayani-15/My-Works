#include<stdio.h>
int main()
{
    int t3,n,t1=0,t2=1,i;
    printf("enter the number of terms:");
    scanf("%d",&n);
    printf("Fibonacci series:");
    for(i=0;i<=n;i++)
    {
       t3=t1+t2;
       t1=t2;
       t2=t3;
       printf("%d",t1);

    }

}
