#include<stdio.h>
void main()
{
    int a=4;
    float b=78.99;
    void *i;
    i=&a;
    printf("the value of integer variable a is:%d\n",*(int*)i);
    i=&b;
    printf("the value of float variable b is:%f\n",*(float*)i);
}
