#include<stdio.h>
#include<string.h>
int main()
{
  char a[40];
  printf("enter the string:");
  gets(a);
  printf("string:%s\n",a);
  int len;
  len=strlen(a);
  printf("length:%d\n",len);
  int i,j;
  int b[20],v;
  for(i=0;i<len;i++)
  {v=1;
      for(j=i+1;j<len;j++)
      {
          if(a[i]==a[j])
          {
              v++;
              a[j]='0';
          }
      }
      b[i]=v;
  }
  int t;
  for(t=0;t<len;t++)
  {
      if(a[t]!='0')
      {
          printf("%c-%d\n",a[t],b[t]);
      }
  }



}
