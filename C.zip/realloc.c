#include<stdio.h>
#include<stdlib.h>
main()
{
    int *a,n,i,m;
    printf("enter the value:\n");
    scanf("%d",&n);
    a=(int*)calloc(n,sizeof(int));
     printf("enter the values:\n");
    for(i=0;i<n;i++)
    {
        scanf("%d",a+i);
    }
    printf("enter the values:\n");
    for(i=0;i<n;i++)
    {
        printf("%d\n",*(a+i));
    }
    printf("\nenter the new size:");
    scanf("%d",&m);
    a=(int*)realloc(a,m*sizeof(int));
    printf("enter the updated elements:");
    for(i=0;i<m;i++)
    {
        scanf("%d",a+i);
    }
       for(i=0;i<m;i++)
    {
        printf("the elements are:%d\n",*(a+i));
    }
}


