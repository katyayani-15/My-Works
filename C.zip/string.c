#include<stdio.h>
#include<conio.h>
main()
{
    char n[20],ch;
    int i=0;
    printf("enter the string:");
    ch=getchar();
    while(ch!='$')
    {
        n[i]=ch;
        i++;
        ch=getchar();
    }
    n[i]='\0';
    printf("output string:");
    printf("%s",n);
}
