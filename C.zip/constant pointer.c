#include<stdio.h>
main()
{
    int a=10;
    const int *p=&a;
    printf("\nvalue of p:%d\n",*p);
    printf("address pointed by p:%p\n",p);
    *p=12;
}
