#include<stdio.h>
int sum(int*,int*);
int main()
{
    int a,b,res,*p,*q;
    p=&a;
    q=&b;
    printf("enter the numbers:");
    scanf("%d%d",&a,&b);
    res=sum(p,q);
    printf("the sum is:%d",res);
}
int sum(int *p,int *q)
{
    int result;
    result=*p+*q;
    return result;
}

