#include<stdio.h>
main()
{
    int i,j,n,m,a[10][10],b[10][10],sum[10][10];
    printf("enter the size:");
    scanf("%d%d",&n,&m);
    printf("enter the elements of the first matrix:");
    for(i=0;i<n;i++)
    {
        for(j=0;j<m;j++)
        {
            scanf("%d",&a[i][j]);
        }
    }
    printf("enter the second matrix:");
    for(i=0;i<n;i++)
    {
        for(j=0;j<m;j++)
        {
            scanf("%d",&b[i][j]);
        }
    }
    for(i=0;i<n;i++)
    {
        for(j=0;j<m;j++)
        {
            sum[i][j]=a[i][j]+b[i][j];
        }
    }
        for(i=0;i<n;i++)
        {
        for(j=0;j<m;j++)
        {
        printf("%d",sum[i][j]);
        }
        printf("\n");
        }

}
