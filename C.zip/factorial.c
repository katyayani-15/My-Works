int main()
{
    int a,i;
    unsigned long long factorial=1;
    printf("enter an integer:");
    scanf("%d",&a);
    if(a<0)
        printf("error! factorial of negative number not exist");
    else
    {
        for(i=1;i<=a;i++)
        {
            factorial*=i;
        }
    }
    printf("factorial is %llu",factorial);
}
