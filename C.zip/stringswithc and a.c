#include<stdio.h>
#include<string.h>
int main()
{
    char a[100][20];
    int i,n,c=0;
    printf("enter the no of strings:");
    scanf("%d",&n);
    for(i=0;i<n;i++)
    {
        printf("enter a string:");
        gets(a[i]);
    }
    printf("enter the strings starting with a and c:");
    for(i=0;i<n;i++)
    {
        if(a[i][0]=='a'||a[i][0]=='c')
        {
            puts(a[i]);
            c++;
        }
    }
    if(c==0)
     puts("no string is found startinng with a and c");
}
