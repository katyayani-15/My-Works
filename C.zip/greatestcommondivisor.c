#include<stdio.h>
int gcd(int,int);
main()
{
    int a,b,res;
    printf("enter the values of a and b:");
    scanf("%d%d",&a,&b);
    res=gcd(a,b);
    printf("the gcd is:%d",res);
}
int gcd(int p,int q)
{
    while(p!=q)
    {
        if(p>q)
        {
            return gcd(p-q,q);
        }
        else
        {
            return gcd(p,q-p);
        }
    }
    return p;
}
