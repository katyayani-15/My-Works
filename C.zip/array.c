#include<stdio.h>
int main()
{
    int a[5],i,j,n;
    int *p[5];
    p[5]=&a[5];
    printf("enter the no of elements:");
    scanf("%d",&n);
    printf("enter the array element\n");
    for(i=0;i<5;i++)
    {
        scanf("%d\n",&a[i]);
    }

    for(j=0;j<5;j++)
    {
        printf("%d,",*p[i]);
    }

}
