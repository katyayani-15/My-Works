#include<stdio.h>
int swap(int *x,int *y)
{
    int z;
    z=*x;
    *x=*y;
    *y=z;
}
main()
{
    int a=70,b=90;
    printf("before swapping:%d\n%d",a,b);
    swap(&a,&b);
    printf("\nafter swapping:%d\n%d",a,b);
}

