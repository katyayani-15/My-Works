#include<stdio.h>
int main()
{
    int *a;
    *a=10;
    printf("%d",*a);
}
