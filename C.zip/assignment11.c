#include<stdio.h>
int octal(int );
int hexadecimal(int);
main()
{
    int n;
    printf("M.KATYAYANI\nID NO:S170464\n");
    printf("Enter decimal number:");
    scanf("%d",&n);
    printf("%d in octal is %d",n,octal(n));
    printf("\n%d in hexadecimal is %d",n,hexadecimal(n));
}
int octal(int n)
{
	int octalnum=0,i=1;
	while(n!=0)
	{
		octalnum+=(n%8)*i;
		n/=8;
		i*=10;
	}
    return octalnum;
}
int hexadecimal(int n)
{
	int hexadecimal=0,i=1;
	while(n!=0)
	{
		hexadecimal+=(n%16)*i;
		n/=16;
		i*=10;
	}
	return hexadecimal;
}
