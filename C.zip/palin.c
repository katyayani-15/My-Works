#include<stdio.h>
int main()
{
    int t,m,e,r;
    t=0;
    printf("enter the value of m\n");
    scanf("%d",&m);
    e=m;
    while(m>0)
    {
    r=m%10;
    t=(t*10)+r;
    m=m/10;
    }
    if(e==t)
        {printf("%d is a pal",e);
        }
    else
    {
        printf("%d is not pal",e);
    }


}
