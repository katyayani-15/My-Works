#include<stdio.h>
int main()
{
    int n,a[20],i,sum,avg;
    printf("enter the no of values");
    scanf("%d",&n);
    printf("enter the elements of array:");
    sum=0;
    for(i=0;i<5;i++)
    {
        scanf("%d\n",&a[i]);
        sum=sum+a[i];

    }
    avg=sum/n;
    printf("%d",avg);
}
