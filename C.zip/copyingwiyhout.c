#include<stdio.h>
void stringcpy(char s2[20],char s1[20]);
int main()
{
    char s1[10],s2[10];
    printf("enter the string:");
    gets(s1);
    stringcpy(s2,s1);
    printf("string1:%s,string2:%s",s1,s2);
}
void stringcpy(char s2[10],char s1[10])
{
    int i;
    for(i=0;s1[i]!='\0';i++)
    {
        s2[i]=s1[i];
    }
    s2[i]='\0';
}

