#include<stdio.h>
int stringcmp(char s1[20],char s2[20]);
int main()
{
    char s1[20],s2[20];
    printf("enter the strings:\n");
    scanf("%s%s",s1,s2);
    if(stringcmp(s1,s2)==0)
    {
        printf("the string are equal");
    }
    else
    {
        printf("the strings are not equal");
    }
}
int stringcmp(char s1[20],char s2[20])
{
    int i;
    for(i=0;s1[1]!='\0';i++)
    {
        if(s1[i]==s2[i])
        {
            return 0;
        }
        else
        {
            return 1;
        }
    }
}
