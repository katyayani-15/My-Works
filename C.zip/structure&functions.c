#include<stdio.h>
struct addition
{
    int a,b,c
}sum;
int addi(int,int,int);
main()
{
    printf("enter the a value:");
    scanf("%d",&sum.a);
    printf("enter the b value:");
    scanf("%d",&sum.b);
    printf("enter the c value:");
    scanf("%d",&sum.c);
    printf("the sum is %d:",addi(sum.a,sum.b,sum.c));

}
int addi(int x,int y,int z)
{
    return x+y+z;
}
