#include<stdio.h>
int main()
{
    int n;
    printf("M.KATYAYANI\nID NO:S170464\n");
    printf("enter the no of days you are late to submit the book:");
    scanf("%d",&n);
    if(n<=5)
    {
        printf("your fine is 50 paise");
    }
    else if (n>=6&&n<=10)
    {
        printf("your fine is one rupee");
    }
    else if(n>10&&n<=30)
    {
        printf("your fine is 5 rupees");
    }
    else if(n>30)
    {
        printf("your membership is canceled");
    }
}
