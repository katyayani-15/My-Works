#include<stdio.h>
int fun(int *p,int *q)
{
          p=q;
           return *p=2;
}
int i=0,j=1;
int main()
{
    fun(&i,&j);
  printf("%d\n%d",i,j);
    return 0;
}

