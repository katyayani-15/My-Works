public class FindAge
{
     public void decide(String s)  throws NumberFormatException,InvalidAge
     {
          int age=Integer.parseInt(s);
          if(age<19)
          {
              throw new InvalidAge("enter valid age");
          }
          else
          {
              System.out.println("ok, you have entered valid age"); 
          } 
      }
}