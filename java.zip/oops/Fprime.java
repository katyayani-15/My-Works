//Even and odd numbers in an array
import java.lang.*;
class Mpro
{
   void cal(int a,int b)
   {
     System.out.println("Prime numbers between "+a+" and "+b+":");
     while(a<b)
     {
       int c=0;
       for(int i=2;i<=a/2;i++)
       {
         if(a%i==0)
         {
            c++;
            break;
          }
       }
       if(c==0)
       {
          dis(a);
       } 
    a++;
   }
 }
    void dis(int c)
    {
       System.out.println(c+"   ");
    } 
}
class Fprime
{
   public static void main(String k[])
   {
     if(k.length!=2)
     {
       System.out.println("please enter only two parameters");
     }
     else
     {
        int lb=Integer.parseInt(k[0]);
        int ub=Integer.parseInt(k[1]);
        Mpro m=new Mpro();
        m.cal(lb,ub);
      }
    }
} 
     
     