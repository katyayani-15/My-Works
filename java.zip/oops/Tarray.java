//Two Dimensional array programs
import java.lang.*;
import java.util.*;
class Dou
{
  void add(int c[][],int d[][],int n,int m)
  { 
     int e[][]=new int[n][m];
      for(int i=0;i<n;i++)
     {
       for(int j=0;j<m;j++)
       { 
          e[i][j]=c[i][j]+d[i][j];
        }
      }
    }
}

class Tarray
{
   public static void main(String k[])
   {
     Scanner sc=new Scanner(System.in);
     System.out.println("Enter the size of the arrays:");
     int n=sc.nextInt();
     int m=sc.nextInt();
     int a[][]=new int[n][m];
     System.out.println("Enter the elements of first array:");
     for(int i=0;i<n;i++)
     {
       for(int j=0;j<m;j++)
       { 
          a[i][j]=sc.nextInt();
        }
      }
      int b[][]=new int[n][m];
     System.out.println("Enter the elements of Second array:");
     for(int i=0;i<n;i++)
     {
       for(int j=0;j<m;j++)
       { 
          b[i][j]=sc.nextInt();
        }
      }
       Dou d=new Dou();
       d.add(a,b,n,m);
    }
}  
     