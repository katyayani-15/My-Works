//Using Array as an object printing student details
import java.lang.*;
import java.util.*;
class Data
{
          static String college="Rgukt Sklm";
          String Name,Branch;
          char Gender;
          double Cgpa;
          Data()
         {
          Scanner s=new Scanner(System.in);
          System.out.println("enter your name:");
          Name=s.nextLine();
          System.out.println("enter your gender:");
          Gender=s.next().charAt(0);
          System.out.println("enter your branch:");
         Branch=s.next();
         System.out.println("enter your cgpa:");
         Cgpa =s.nextDouble();
     }
     void display()
     {
       System.out.println("Name of the student:"+Name);
         System.out.println("College:"+college);
     }
}
class Det
{
  public static void main(String k[])
  {
     Scanner s=new Scanner(System.in);
     System.out.println("enter the no of students:");
     int n=s.nextInt();
     Data d[]=new Data[n];
     for(int i=0;i<n;i++)
     {
       d[i]=new Data();
     }
     for(int i=0;i<n;i++)
     {
       d[i].display();
     }
     
   }
}
    
    

      