//Accept float value from cmd and display square of it.
import java.lang.*;
class Square
{
   float f,res;
   void cal(float e)
   { 
      f=e;
      res=f*f;
      display();
   }
   void display()
   {
     System.out.println("Square of given float number is:"+res);
   }
 }
class Value
{ 
   public static void main(String k[])
   {
      System.out.println("Start of main method");
      if(k.length!=1)
      {
        System.out.println("Please enter only one argument");
      }
      else
      {
        float a=Float.parseFloat(k[0]);
        Square s=new Square();
        s.cal(a);
        System.out.println("End of main method");
       }
    }
}