//Largest,Smallest,Second largest and second smallest numbers in an array.
import java.lang.*;
import java.util.*;
class Small
{
   void secl(int b[],int m)
   {
       int temp;
      for(int i=0;i<m;i++)
      {
         for(int j=i+1;j<m;j++)
         {
             if(b[i]>b[j])
             {
               temp=b[i];
               b[i]=b[j];
               b[j]=temp;
             }
          }
       }
       dis(b,m);
    }
    void dis(int c[],int n)
    {
        System.out.println("Largest number in the array is:"+c[n-1]);
        System.out.println("Second Largest number in the array is:"+c[n-2]);
     }
    void secs(int d[],int m)
   {
       int temp;
      for(int i=0;i<m;i++)
      {
         for(int j=i+1;j<m;j++)
         {
             if(d[i]<d[j])
             {
               temp=d[i];
               d[i]=d[j];
               d[j]=temp;
             }
          }
       }
       dis1(d,m);
    }
    void dis1(int e[],int n)
    {
        System.out.println("Smallest number in the array is:"+e[n-1]);
        System.out.println("Second Smallest number in the array is:"+e[n-2]);
     }
}
class Large
{
   public static void main(String k[])
    { 
        Scanner s=new Scanner(System.in);
        System.out.println("Enter no of elements :");
        int n=s.nextInt();
        int a[]=new int[n];
        System.out.println("Enter  elements :");
        for(int i=0;i<n;i++)
        {
           a[i]=s.nextInt();
        }
        Small t=new Small();
        t.secl(a,n);
        t.secs(a,n);
     }
}
