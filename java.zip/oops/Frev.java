//Reverse and duplicate numbers in an array
import java.lang.*;
import java.util.*;
class Devl
{
   void mp(int b[],int m)
   {
      System.out.println("Reverse of numbers in the array:");
      for(int i=m-1;i>=0;i--)
      {
          System.out.println(b[i]+" ");
       }
   }
} 
            
class Frev
{ 
    public static void main(String k[])
   {
      Scanner s=new Scanner(System.in);
      System.out.println("enter no of elements:");
      int n=s.nextInt();
      int a[]=new int[n];
      System.out.println("enter elements:");
      for(int i=0;i<n;i++)
      {
        a[i]=s.nextInt();
      }
      Devl d=new Devl();
      d.mp(a,n);
    }
}

      