import java.lang.*;
import java.util.*;
class Program
{
   void even(int b[],int n)
   {
       System.out.println("Even elements:");
      for(int i=0;i<n;i++)
      {
        if(b[i]%2==0)
        {
          System.out.println(b[i]);
        }
     }
  }
     void odd(int c[],int n)
     {  
         System.out.println("Odd elements:");
        for(int i=0;i<n;i++)
      {
        if(c[i]%2!=0)
        {
          System.out.println(c[i]);
        }
     }
   }
}      
class Farray
{ 
  public static void main(String k[])
  {
     Scanner sc=new Scanner(System.in);
     System.out.println("enter no of elements:");
     int n=sc.nextInt();
     int a[]=new int[n];
     System.out.println("enter elements:");
     for(int i=0;i<n;i++)
     {
       a[i]=sc.nextInt();
     }
     Program p=new Program();  
     p.even(a,n);
     p.odd(a,n);
     
   }
}
         