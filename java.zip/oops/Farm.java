//Given number is Armstrong and Palindrom or not.
import java.lang.*;
class Fpal
{
   void prog(int y)
    {
        int r,s=0,t=y;
        while(y!=0)
        {
           r=y%10;
           s=s+(r*r*r);
           y=y/10;
        }
        dis(s,t);
    }
    void dis(int e,int f)
    {
       if(e==f)
       {
          System.out.println(f+" is an Armstrong number");
        }
       else
       {
         System.out.println(f+"  is not an armstrong number");
        }
     }
     void poo(int h)
     {
        int r,s=0,u=h;
        while(h!=0)
        {
           r=h%10;
           s=(s*10)+r;
           h=h/10;
        }
        display(s,u);
     }
     void display(int c,int d)
     {
        if(c==d)
        {
             System.out.println(d+"  is a Palindrom number");
         }
        else
        {
             System.out.println(d+"  is not a Palindrom number");
        }
    }
        
}

class Farm
{
   public static void main(String k[])
    {
        if(k.length!=1)
        {
           System.out.println("please enter only one parameter");
         }
         else
          {
           int a=Integer.parseInt(k[0]);
           Fpal j=new Fpal();
           j.prog(a);
           j.poo(a);
          }
      }
}
         
           
       