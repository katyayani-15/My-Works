//Swap two numbers in three ways
import java.lang.*;
class Pro
{ 
   void swap1(int e,int f)//using third variable
   {
     int g;
     System.out.println("In swap1 method");
     System.out.println("Numbers before swaping:e="+e+"f="+f);
     g=e;
     e=f;
     f=g;
     System.out.println("Numbers after swaping:e="+e+"f="+f);
    }
    void swap2(int u,int v)//using +,- operators
    {
      System.out.println("In swap2 method");
      System.out.println("Numbers before swaping:u="+u+"v="+v);
      u=u+v;
      v=u-v;
      u=u-v;
      System.out.println("Numbers after swaping:u="+u+"v="+v);
    }
  void swap3(int x,int y)//using XOR operator
    {
      System.out.println("In swap3 method");
      System.out.println("Numbers before swaping:x="+x+"y="+y);
      x=x^y;
      y=x^y;
      x=x^y;
      System.out.println("Numbers after swaping:x="+x+"y="+y);
    }
}
      
class Fswap
{
  public static void main(String k[])
  {
    if (k.length!=2)
    {
       System.out.println("Please enter only two parameters");
     }
     else
     {
       int a=Integer.parseInt(k[0]);
       int b=Integer.parseInt(k[1]);
       Pro p=new Pro();
       p.swap1(a,b);
       p.swap2(a,b);
       p.swap3(a,b);
      }
    }
}