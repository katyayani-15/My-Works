//Copy the numbers in an array into another and duplicate elements in the array.
import java.lang.*;
import java.util.*;
class Mai
{
   void cali(int b[],int m)
   {
     int c[]=new int[m]; 
     for(int i=0;i<m;i++)
     {
       c[i]=b[i];
     }
     dis(c,m);
   }
   void dis(int d[],int l)
   {
      System.out.println("Copied array:");
      for(int i=0;i<l;i++)
      {
         System.out.println(d[i]+"  ");
      }
   }
   void dupli(int v[],int z)
   {
      System.out.println("Duplicate numbers are:  ");
      for(int i=0;i<z;i++)
      {
         for(int j=i+1;j<z;j++)
         {
            if( v[i]==v[j])
            {
               disp(v[i]);
            }
         }
      }
     }
   void disp(int t)
    {
       System.out.println(t+"  ");
    }
             
}
      

class Fcopy
{
   public static void main(String k[])
   {
   Scanner sc=new Scanner(System.in);
   System.out.println("enter no of elements in the array:");
   int n=sc.nextInt();
   int a[]=new int[n];
   System.out.println("enter  elements:");
   for(int i=0;i<n;i++)
   {
     a[i]=sc.nextInt();
   }
   Mai x=new Mai();
   x.cali(a,n); 
   x.dupli(a,n);
   }
} 