class UDE1
{
       public static void main(String a[])
       {
            try{
            String s1=a[0];
            FindAge f=new FindAge();
            f.decide(s1);
            }
            catch(ArrayIndexOutOfBoundsException e)
            {
                 System.out.println("please pass values through cmd");
            }
            catch(NumberFormatException f)
            {
                 System.out.println("please pass integer values only");
            }
            catch(InvalidAge i)
            {
                 System.out.println(i.getMessage());
            }
           catch(Exception y)
           {
                System.out.println("please enter input correctly");
           }
       }
}