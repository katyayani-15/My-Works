//Frequency of the elements in an array
import java.lang.*;
import java.util.*;
class Pop
{
   int e;
    void fun(int b[], int z)
   {  
    int c[]=new int[z];
    for(int k=0;k<z;k++)
    {
      c[k]=-1;
    }
    for(int i=0;i<z;i++)
      {
         e=1;
         for(int j=i+1;j<z;j++)
         {
            if( b[i]==b[j])
            {
              e= e+1;
              c[j]=0;
            }
         }
        if(c[i]!=0)
        {
          c[i]=e;
        }
      } 
      dis(c,z,b);
    }
    void dis(int d[],int m,int e[])
    {
        for(int i=0;i<m;i++)
     {
       if(d[i]!=0)
       {
         System.out.println("Frequency of"+e[i]+":"+d[i]);
        }
     }
    }
}
class Freq
{
   public static void main(String k[])
    {
       Scanner sc=new Scanner(System.in);
       System.out.println("enter the no of elements:");
       int n=sc.nextInt();
       int a[]=new int[n];
       System.out.println("enter elements:");
       for(int i=0;i<n;i++)
       {
          a[i]=sc.nextInt();
       }
       Pop p=new Pop();
       p.fun(a,n);
     }
}
 