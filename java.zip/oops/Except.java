import java.util.Scanner;
class Except
{
      public static void main(String t[])
      {
           Scanner s=new Scanner(System.in);
           System.out.println("enter a value:");
           int a=s.nextInt();  
           System.out.println("enter b value:");
           int b=s.nextInt();
           int i[]=new int[5];
           for(int j=0;j<5;j++)
           {
               System.out.println("enter value:");
               i[j]=s.nextInt();
           }
           try
           {
               System.out.println("result is :"+(a/b));
               System.out.println("Try block executed");
               System.out.println("array value:"+i[6]);
           }
           catch(ArithmeticException d)
           {
              System.out.println("Denominator should not be zero");
           }
           catch(Exception e)
           {
              System.out.println("Array is out of bound");
           }
     }
}