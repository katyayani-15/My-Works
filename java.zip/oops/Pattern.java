//pattern of first letter of my surname
import java .lang.*;
class Poly
{
   void m()
  {
     for(int i=0;i<5;i++)
     {  
       System.out.printf(" ");
       for(int j=0;j<5;j++)
       { 
          if(j==0||j==4)
          {
             System.out.printf("M");
          }
          else if(i<3&&(j==i||j==4-i))
          {
             System.out.printf("M");
          }
          else
          {
             System.out.printf(" ");
          }
        }
       System.out.println("\n");
      }
   }
}
class Pattern
{
  public static void main(String k[])
  {
     System.out.println("Start of main method");
     Poly p=new Poly();
     p.m();
   }
}
  
     
  