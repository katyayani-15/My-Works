import java.util.*;
public class UDE extends Exception
{
        UDE(String s1)
         {
              super(s1);
         }
        public static void main(String a[])
        {
               Scanner s=new Scanner(System.in);
               try{
               String rno=a[0];
               System.out.println("enter your age:");
               int age=s.nextInt();
               if(age<19)
               {
                      throw new UDE("please enter age more than 19");
                }
               System.out.println("entered age is:"+age);
               if(rno.length()!=7)
               {
                    throw new UDE("enter rno correctly");
               }
               System.out.println("entered rno is:"+rno);
               }
               catch(UDE y)
               {
                   System.out.println(y.getMessage());
               }
               catch(Exception e)
              {
                   System.out.println("there is a problem in the inputs given");
              }
       }
}
               