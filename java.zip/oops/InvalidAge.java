public class InvalidAge extends Exception
{
        public InvalidAge(String s)
        {
            super(s);
         
        }
}