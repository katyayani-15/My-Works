import java.lang.*;
import java.util.Scanner;
class Pat
{
void pat(int b[][],int n)
{
  int i,j;
  if(n>2||n%2!=0)
    {
    for(i=0;i<n;i++)
    {
        System.out.println();
        for(j=0;j<n;j++)
        {
            if(j==0||((i+j)==(n-1)&&(i<n/2))||((i==j)&&(i>1)&&(i>=(n/2)))||((i==n/2)&&(j<=n/2)))
            {
                System.out.print("*");
            }

            else
            {
                System.out.print(" ");

            }

        }
    }
    }
    else
    {
        System.out.println("enter only positive odd numbers for proper pattern");
    }
}
}
class Pattern
{
public static void main(String k[])
{
    Scanner s=new Scanner(System.in);
    System.out.println("enter the no of rows and columns:");
    int n=s.nextInt();
    int a[][]=new int[n][n];
    Pat p=new Pat();
    p.pat(a,n);
}
}

   