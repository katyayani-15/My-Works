import java.lang.*;
class Palin
{
public static void main(String h[])
{
    if(h.length!=1)
    {
       System.out.println("enter only one parameter:");
    }
    else
    {
    int m=Integer.parseInt(h[0]);
    int t,e,r;
    t=0;
    e=m;
    while(m>0)
    {
    r=m%10;
    t=(t*10)+r;
    m=m/10;
    }
    if(e==t)
        {
          System.out.println(e+" is a palindrome ");
        }
    else
    {
        System.out.println(e+" is not palindrome");
    }


}
}
}
