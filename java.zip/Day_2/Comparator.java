import java.lang.*;
import java.util.*;
class K
{
  void convert(int c,int d)
  {
    if(c>15||d>15||c<0||d<0)
     {
        System.out.println("Given number cannot be represented in 4 bit");
    }
   else
{
   int e=0;
   int g=c;
   int i=3;
   int a[]=new int[4];
   while(g!=0)
    {
     e=g%2;
     g=g/2;
     while(i>=0)
     { 
       a[i]=e;
       break;
    }
   i--;
    }
  for(int k=0;k<4;k++)
  {
   System.out.print(a[k]);
  }
   int f=0,j=3;
   int h=d;
   int b[]=new int[4];
   while(h!=0)
   {
     f=h%2;
     h=h/2;
     while(j>=0)
     { 
       b[j]=f;
       break;
     }
   j--;
  }
  System.out.println("\n");
  for(int l=0;l<4;l++)
  {
   System.out.print(b[l]);
  }
  int u=0,v=0,r=0;
  while(r<=3)
  {
  if(a[r]>b[r])
  {
     u=1;
     break;
  }
  else if(a[r]==b[r])
  {
     r++;
  }
  else
{
   v=1;
   break;
}
  
}
System.out.println();
System.out.println(c);
 if(u==1)
{
 System.out.println(c+"  greater than "+d);
}
else if(u==0&&v==0)
{
  System.out.println(c+" equal to "+d);
}
else
{
  System.out.println(c+"  less than  "+d);
}
    }
}
}

    
     
     
class Comparator
{
   public static void main(String o[])
   {
     Scanner s=new Scanner(System.in);
     System.out.println("Enter two decimal numbers:");
     int a=s.nextInt();
     int b=s.nextInt();
     K k=new K();
     k.convert(a,b);
  }
}
    