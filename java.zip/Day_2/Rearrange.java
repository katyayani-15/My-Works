import java.lang.*;
import java.util.*;
class R
{
  void pro()
   {
      Scanner s=new Scanner(System.in);
      int m=s.nextInt();
      int a[]=new int[m];
      int b[]=new int[m];
      int i;
      int k=m-1;
      int j=0;
      for(i=0;i<m;i++)
      {
        a[i]=s.nextInt();
        if(a[i]%2!=0)
        {
             
              b[j]=a[i];
              j++;
           }
         else
          {
                
                  b[k]=a[i];
                  k++;
         }
        
     }

int o;
    System.out.println(" elements:");
    for(o=0;o<m;o++)
    {
       System.out.println(b[o]);
    }

}
}

            

class Rearrange
{
  public static void main(String d[])
  {
  R r=new R();
  r.pro();
  }
}
  