import java.lang.*;
import java.util.Scanner;
class Q
{
  void sum(int b[][],int m)
{
   int s,l=0,i,j;
   int c[]=new int[3];
   for( j=0;j<m;j++)
   {
      s=0;
      for(i=0;i<3;i++)
      {
         s=s+b[i][j];
      }
     c[l]=s;
     l++;
}
dis(c);
}
void dis(int d[])
{
  System.out.println("Sum of all Quadratic equations are:");
int i;
  for( i=0;i<3;i++)
{
   System.out.println("  "+d[i]);
}
}
}
   
class QuadraticS
{
  public static void main(String K[])
{
   Scanner s=new Scanner(System.in);
  System.out.println("enter the no of quadratic equation:");
   int n=s.nextInt();
  if(n<3)
  {
     System.out.println("enter equations more than 2");
  }
else
{
 int a[][]=new int[n][3];
int i,j;
 System.out.println("enter the coefficients:");
  for( i=0;i<n;i++)
{
 for( j=0;j<3;j++)
{
   a[i][j]=s.nextInt();
}
}
   Q q=new Q();
  q.sum(a,n);
}
}
}
 