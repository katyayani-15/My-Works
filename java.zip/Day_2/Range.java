import java.lang.*;
import java.util.*;
class App
{
  int count=0;
  void cal(int l,int u,int n)
  {
     if(n<=0)
     {
       System.out.println("Give valid divisor");
     }
     else
     {
     int i;
     for(i=l;i<=u;i++)
     {
        if(i%n==0)
        { 
           count++;
        }
    }
  dis(count,n);
}
}
void dis(int w,int n)
{
  System.out.println("Number of integers which are divisible by "+n+" in the given range are:"+w);
}
}


class Range
{
  public static void main(String g[])
{
  Scanner s=new Scanner(System.in);
  System.out.println("enter the lower and upper bound:");
  int l=s.nextInt();
  int u=s.nextInt();  
 System.out.println("enter the number which divides:");
 int n=s.nextInt();
 App a=new App();
 a.cal(l,u,n);
} 
}
  