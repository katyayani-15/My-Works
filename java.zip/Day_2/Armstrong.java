import java.lang.*;
import java.util.*;
class Arm
{
    void arm(int x)
	{
		int n,rem,sum=0;
        n=x;
		while(n!=0)
		{
			rem=n%10;
			sum=sum+(rem*rem*rem);
			n=n/10;
		}
		if(sum==x)
		{
			System.out.println(x+" is an armstrong number!!!");
		}
		else
		{
			System.out.println(x+" is not an armstrong number!!!");
		}
	}
}
class Armstrong
{
    public static void main(String args[])
	{
	   Scanner sc=new Scanner(System.in);
	   System.out.println("Enter any number to check whether it is armstrong or not:");
	   int n=sc.nextInt();
       Arm a=new Arm();
	   a.arm(n);
	}
}