import java.lang.*;
import java.util.*;
class Pro
{
   long x=1;
  void cali(int n)
  { 
     int t3;
     Scanner s=new Scanner(System.in);
     System.out.println("enter the intial values:");
     int t1=s.nextInt();
     int t2=s.nextInt();
     System.out.println("Fibnocci series of the given number:");
     if(n==0)
     {
        System.out.println("enter any except 0");
     }
     else
     {
     for(int i=1;i<=n;i++)
     {
       display(t1);
       t3=t2+t1;
       t1=t2;
       t2=t3;
     }
    }
  }
  void display(int y)
  {
    System.out.println(y+"  ");
  }

 }
   
  
class Fibno
{
   public static void main(String k[])
   { 
     if(k.length!=1)
     {
       System.out.println("Please enter only one parameter");
     }
     else
     {
       int m=Integer.parseInt(k[0]);
       Pro l=new Pro();
       l.cali(m);
     }
    }
}