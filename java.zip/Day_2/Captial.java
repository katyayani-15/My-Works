import java.lang.*;
import java.util.Scanner;
class Captial
{
   public static void main(String l[])
{
   Scanner s=new Scanner(System.in);
   String h=s.nextLine();
  char c[]=h.toCharArray();
  int i;
  for(i=0;i<c.length;i++)
  {
     if(i==0)
     {
       c[i]=Character.toUpperCase(c[i]);
     }
    if(c[i]==' ')
   {
      c[i+1]=Character.toUpperCase(c[i+1]);
   }
 }
int j;
for(j=0;j<c.length;j++)
{
   System.out.println(c[j]);
}
}
}
   