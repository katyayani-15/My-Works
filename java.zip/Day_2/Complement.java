import java.lang.*;
import java.util.*;
class Forpower
{
    int powerofnum(int r,int c)
    {
     int n=1;
      while(c!=0)
      {
      n=n*r;
      c--;
      }
     return n;
    }
   void convertion(int r,int v,int n)
   {
    int t=v,i=0,j=0,m=0,q,z;
    int a[]=new int[50];
    int ac[]=new int[50];
    int b=0,c=0;
    if(r==10)
    {
    System.out.print(r+"'s complement of given value is "+(v-n)+"\n");
    System.out.print((r-1)+"'s complement of given value is "+(v-n-1));
    }
    else if(r==8)
    {  
     q=n;
     while(q>0)
     {
       b+=(q%10)*powerofnum(8,j);
       j++;
       q=q/10;
     }
     b=v-b;
     c=b-1;
    while(b>0)
    {
      a[i++]=b%8;
      b=b/8;
    }
    z=0;
    while(c>0)
    {
      ac[z++]=c%8;
      c=c/8;
    }
    System.out.print(r+"'s complement of given value is ");
   for(j=(i-1);j>=0;j--)
   {
    System.out.print(a[j]);
   }
   System.out.print("\n"+(r-1)+"'s complement of given value is ");
   for(j=(z-1);j>=0;j--)
   {
    System.out.print(ac[j]);
   }
  }
}
}
class Complement
{
  public static void main(String k[])
{
   int n,c=0,r,t,y,z,i=0,j,sum=0;
   int a[]=new int[10];
   Forpower obj=new Forpower();
   System.out.print("Enter which complement you want to check(Radix) : ");
   Scanner sc=new Scanner(System.in);
   r=sc.nextInt();
   System.out.print("Enter the number : ");
   n=sc.nextInt();
   t=n;
   while(t!=0)
   {
      t=t/10;
      c++;
   }
   t=n;
   if(r==2)
   {
     while(t>0)
     {
       a[i++]=t%2;
       t=t/2;
     }
     for(j=(i-1);j>=0;j--)
     {
       if(a[j]==0)
       a[j]=1;
       else
       a[j]=0;
     }
     for(j=i;j>=0;j--)
     {
      System.out.print(a[j]);
     }
    System.out.print("\n");
     for(j=i;j>=0;j--)
     {
      sum+=(a[j]*obj.powerofnum(2,(j)));
     }
   System.out.print(r+"'s complement of given value is"+(sum+1)+"\n");
   System.out.print((r-1)+"'s complement of given value is"+(sum));
 }
else
{
   y=obj.powerofnum(r,c);
   obj.convertion(r,y,n);
}
}
}

   
   