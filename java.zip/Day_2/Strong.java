 import java.lang.*;
 import java.util.*;
 class StrongNum
 {
	 void strong(int n)
	 {
		 int x=n;
		 int rem=0,sum=0,fact,i;
         while(x!=0)
		 {
			 rem=x%10;
			 fact=1;
             for(i=1;i<=rem;i++)
			 {
				 fact=fact*i;
			 }
			 sum=sum+fact;
			 x=x/10;
		 }
		 if(sum==n)
		 {
			 System.out.println(n+" is a strong number!!!");
		 }
		 else
		 {
             System.out.println(n+" is not a strong number!!!");
		 }
	 }
 }
 class Strong
 {
	public static void main(String args[])
	 {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter any positive integer to check whether it is strong otr not:");
		int n=sc.nextInt();
		StrongNum s=new StrongNum();
		s.strong(n);
	 }
 }