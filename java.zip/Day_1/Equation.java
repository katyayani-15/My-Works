import java.lang.*;
import java.util.*;
class Quadratic
{
        void assign()
        {
                Scanner s=new Scanner(System.in);
               System.out.println("enter the coefficient of x^2");
              int a=s.nextInt();
               System.out.println("enter the coefficient of x^1");
              int b=s.nextInt();
             System.out.println("enter the constant");
              int c=s.nextInt();
             int d=b*b-4*a*c;
             if(d>0)
             {
                         System.out.println("roots are real and distinct");
                        double root1=(-b+Math.sqrt(d))/(2*a);
                        double root2=(-b-Math.sqrt(d))/(2*a);
                        System.out.println("root1 is:"+root1+" root2 is:"+root2);
             }
             else if(d==0)
             {
                        System.out.println("roots are real and equal");
                        int root1=(-b)/(2*a);
                        System.out.println("root1=root2="+root1);
             }
             else
            {
                    System.out.println("roots are imaginary and distinct");
                    System.out.println("root1="+((-b/(2*a))+"+i"+(Math.sqrt(-d))/(2*a)));
                   System.out.println("root2="+((-b/(2*a))+"-i"+(Math.sqrt(-d))/(2*a)));
            }
        }
}
class Equation
{
         public static void main(String a[])
         {
         Quadratic o=new Quadratic();
         o.assign();
        }
}