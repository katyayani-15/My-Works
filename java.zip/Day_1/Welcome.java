import java.lang.*;
class Welcome
{
public static void main(String k[])
{
   System.out.println("Welcome to Cse department");
}
}