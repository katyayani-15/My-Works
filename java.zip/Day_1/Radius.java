import java.lang.*;
import java.util.Scanner;
class Circle
{ 
  void in()
{
  Scanner s=new Scanner(System.in);
  System.out.println("enter the radius :");
  double a=s.nextDouble();
  double g;
  g=3.14*a*a;
  dis(g);
}
void dis(double t)
{
   System.out.println("Area of circle is:"+t);
}
}
  
  
class Radius
{
  public static void main(String k[])
{
   Circle c=new Circle();
   c.in();
}
}