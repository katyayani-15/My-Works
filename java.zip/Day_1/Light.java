import java.lang.*;
class Light
{
  public static void main(String k[])
   {
   int days=7;
   System.out.println("Distance travelled in "+days+  " by light is ="+days*24*60*60*186000);
}
}
   