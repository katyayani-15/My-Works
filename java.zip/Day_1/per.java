import java.lang.*;
import java.util.Scanner;
class Student
{
       int i,j;
        void assign()
        {
              Scanner s=new Scanner(System.in);
              System.out.println("enter the number of students:");
              int n=s.nextInt();
               int a[][]=new int[n][6];
              for(i=0;i<n;i++)
              {
                      System.out.println("enter the marks for each subject of the student:");
                      for(j=0;j<6;j++)
                      {
                            a[i][j]=s.nextInt();
                      }  
              }
             System.out.println("enter the actual marks for each subject");
            int m=s.nextInt();
            int total=6*m;
            calculate(a,n,total);
        }
       void calculate(int a[][],int n,int total)
       {
               for(i=0;i<n;i++)
            {
                   int sum=0;
                   for(j=0;j<6;j++)
                   {
                           sum=sum+a[i][j];
                   }
                  System.out.println("total marks of student  is:"+sum);
                 System.out.println("percentage of student is:"+(sum*100)/total+"%");
            }
       }
}
class Per
{
    public static void main(String k[])
    {
          Student s=new Student();
         s.assign();
    }
}