import java.lang.*;
class D
{
  void inp(int c,int d)
{
  if((d%4==0&&d%100!=0)||d%400==0)
 {
   if(c==2)
   {
     System.out.println("Number of days in "+c+" month is:"+29);
   }
   else
  {
    System.out.println("Number of days in "+c+" month is :"+28);
  }
 }
else
{
   if(c==1||c==3||c==5||c==7||c==8||c==10||c==12)
   {
     System.out.println("Number of days in "+c+" month is:"+31);
  }
  else
{
  System.out.println("Number of days in "+c+" month is:"+30);
}
}
}
}
class Year
{
  public static void main(String k[])
{  
  if(k.length!=2)
  {
    System.out.println("Enter only two parameters");
  }
else
{
  int c=Integer.parseInt(k[0]);
  int d=Integer.parseInt(k[1]);
  D e=new D();
 if((c>12||c<=0)||d<=0)
{
  System.out.println("Enter valid month and year");
}
else
{
  e.inp(c,d);
}
}
}
}
