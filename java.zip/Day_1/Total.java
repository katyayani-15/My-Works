import java.lang.*;
import java.util.Scanner;
class Percentage
{
 void cal(int a[],int m)
{
  float x=0;
  for(int i=0;i<m;i++)
{
   x=x+a[i];
}
dis(x);
}
void dis(float r)
{
  float o;
  System.out.println("Total marks of the student: "+r);
  o=((r/(6*100))*100);
  System.out.println("Percentage of the student marks : "+o+" % ");
}
}
class Total
{
  public static void main(String w[])
{ 
  Scanner s=new Scanner(System.in);
  int t[]=new int[6];
  for(int i=0;i<6;i++)
{
   t[i]=s.nextInt();
   if(t[i]>100||t[i]<0)
   {
     System.out.println("enter valid marks");
     i--;
   }
}
Percentage p=new Percentage();
p.cal(t,6);
}
}
  