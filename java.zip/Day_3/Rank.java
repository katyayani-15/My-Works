import java.lang.*;
import java.util.*;

class Rank
{

	String str;
	int len,i,j,c,s,x;
	int arr[]=new int[20];
		int fact(int n)
		{
			if(n==0 || n==1)
				return 1;
			else
				return n*fact(n-1);
		}	

	void read()
	{
		Scanner sc = new Scanner(System.in);
		System.out.print("Enter the string: ");
		str = sc.next();
		len=str.length();
		for(i=0;i<len;i++)
		{
			c=0;
			for(j=i+1;j<len;j++)
			{
				if(str.charAt(i)>str.charAt(j))
					c++;	
			}
			arr[i]=c;
		}
		
		s=0;
		x=len-1;
		for(i=0;i<len;i++)
		{
			s=s+(arr[i]*fact(x));
			x--;
		}
		s=s+1;
		System.out.print("The rank of the word "+str+" is: "+s);

	}
}

class Rank
{
	public static void main(String args[])
	{
		Rank ob = new Rank();
		ob.read();
	}	
}