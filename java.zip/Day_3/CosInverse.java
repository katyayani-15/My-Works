import java.lang.*;
import java.util.*;
class Q
{
   double o=1;
   double power(double y,double z)
  {
     
      if(z==0)
      {
         return o;
      }
      else
      {
      o=o*y;
       return(power(y,z-1));
      }
}
}
class CosInverse
{
  public static void main(String h[])
{
   Q q=new Q();
   Scanner s=new Scanner(System.in);
   System.out.println("enter the value of n:");
   int n=s.nextInt();
   System.out.println("enter the value:");
   double x=s.nextFloat();
  double sum=x;
  double k=1;
  double w;
  for( int i=3;i<=n;i=i+2)
  {
     k=k*(i-2)/(i-1);
     w=q.power(x,i)/i;
     sum+=k*(w);
     
  }
  sum=1.57-sum;
  System.out.println("Value of cos^-1(x): "+sum*57.296);
}
}