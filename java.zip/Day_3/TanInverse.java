import java.lang.*;
import java.util.*;
class T
{
   double o=1;
   double power(double y,int z)
  {
      if(z==0)
      {
         return o;
      }
      else
      {
      o=o*y;
       return(power(y,z-1));
      }
}
}
class TanInverse
{
  public static void main(String h[])
{
   T t=new T();
   Scanner sc=new Scanner(System.in);
   System.out.println("enter the value of n:");
   int n=sc.nextInt();
   System.out.println("enter the value:");
  double x=sc.nextDouble();
  double sum=1.57;
  int sign=-1;
  double w;
  for(int i=1;i<=n;i=i+2)
  {
     sum+=sign*(1/(i*(t.power(x,i))));
     sign=sign*(-1);
     
  }
  System.out.println("Value of tan^-1(x): "+sum*57.296);
}
}