import java.lang.*;
import java.util.*;
import java.lang.Math;
class Ex
{
  public static void main(String j[])
{
   Scanner s=new Scanner(System.in);
   System.out.println("enter the value of n:");
   int n=s.nextInt();
   System.out.println("enter the value of x:");
   int x=s.nextInt();
  double sum=1+x;
   int fact=1;
  for(int i=2;i<=n;i++)
  {
     fact=fact*i;
     sum=sum+Math.pow(x,i)/fact;
  }
  System.out.println("e^"+x+": "+sum);
}
}