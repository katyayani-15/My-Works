import java.lang.*;
import java.util.*;
class D
{
   float o=1;
   float power(float y,float z)
  {
     
      if(z==0)
      {
         return o;
      }
      else
      {
      o=o*y;
       return(power(y,z-1));
      }
}
}
class SinInverse
{
  public static void main(String h[])
{
   D d=new D();
   Scanner s=new Scanner(System.in);
   System.out.println("enter the value of n:");
   int n=s.nextInt();
   System.out.println("enter the value:");
   float x=s.nextFloat();
  float sum=x;
  float k=1;
  float w;
  for( int i=3;i<=n;i=i+2)
  {
     k=k*(float)(i-2)/(i-1);
     w=d.power(x,i);
     sum=sum+k*(w/i);
     
  }
  System.out.println("Value of sin^-1(x): "+sum*57.296);
}
}