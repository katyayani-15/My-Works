import java.lang.*;

import java.util.*;

class SquareRoot
{
	
   public static void main(String args[])
   {
	
       int num;
	
      double root;
	
      Scanner read=new Scanner(System.in);
	
      System.out.println("Enter the number you want to find Square root:");
	
     num=read.nextInt();
	
     root=Math.pow(num,(float)1/2);
	
     System.out.println(root);
	
   }


}
