import java.lang.*;
import java.util.*;
import java.lang.Math;
class Sinx
{
  public static void main(String j[])
{
   Scanner s=new Scanner(System.in);
   System.out.println("enter the value of n:");
   int n=s.nextInt();
   System.out.println("enter the degree:");
   double x=s.nextDouble();
   double r=x*(3.14/180);
  double sum=r,sign=-1,fact=1;
  for(int i=3;i<=n;i=i+2)
  {
     fact=fact*i*(i-1);
     sum=sum+(sign*(Math.pow(r,i)))/fact;
     sign=sign*-1;
  }
  System.out.println("Value of sinx: "+sum);
}
}