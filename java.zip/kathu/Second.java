import java.lang.*;
class Second
{  
   public static void main(int a)
   { 
      System.out.println("int method");
      main();
   }
   public static void main(String k[])
   {
     System.out.println("main method");
     main(7);
   }
   public static void main(float b)
   {
     System.out.println("float method");
   }
   public static void main()
   {
     System.out.println("without arguments method");
     main(5.4f);
   }
}