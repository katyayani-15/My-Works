//Using scanner files
import java.lang.*;
import java.util.*;
class Fscanner
{
   public static void main(String K[])
   {
      Scanner s=new Scanner(System.in);
      System.out.println("enter your name:");
      String Name=s.nextLine();
      System.out.println("enter your gender:");
      char Gender=s.next().charAt(0);
      System.out.println("enter your branch:");
      String Branch=s.next();
      System.out.println("enter your mobile number:");
       while(!s.hasNextLong());
      {
        String b=s.next();
       }
      long Mobile=s.nextLong();
      System.out.println("enter your cgpa:");
      double Cgpa =s.nextDouble();
      System.out.println("Name of the student:"+Name);
      System.out.println("Gender:"+Gender);
      System.out.println("Branch:"+Branch);
      System.out.println("Mobile Number:"+Mobile);
      System.out.println("CGPA:"+Cgpa);
    }
}

      