import java.lang.*;
class Fcmd
{
   public static void main(String z[])
   {
      if(z.length!=2)  
      {
        System.out.println("please enter only two parameters");
       }
      else
      {
        System.out.println("start of main method");
        System.out.println(z[0]);
        System.out.println(z[1]);
        int k=Integer.parseInt(z[0]);
        int s=Integer.parseInt(z[1]);
         System.out.println("addition operator over strings:"+(z[0]+z[1]));
         System.out.println("addition operator over integers:"+(k+s));
         System.out.println("End of the main method");
      }
   }
}
