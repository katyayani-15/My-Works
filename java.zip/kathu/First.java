import java.lang.*;
class Mul
{
   int a,b,c;
   void assign()
   { a=9;
     b=7;
   }
   void multiply()
   {
      c=a*b;
   }
   void display()
   {
      System.out.println("Multiplication of two numbers is:"+c);
    } 
}
class Add
{  
   static int a=10;
  int b=8;
   static void sum()
{ 
    System.out.println("Static variable is:"+a);
    Add p=new Add();
    System.out.println("Instance variable is:"+p.b);//static method calling instance variable 
}
   void imul()
 { 
    Add.sum();//instance method calling static method
 }
void jmul()
{
  imul(); //instance method calling instance method
}
static void sub()
{
   sum();static method calling static method
}
}


class First
{
   public static void main(String k[])
  {
     System.out.println("From main method");
     Mul m=new Mul();
     m.assign();//static method calling instance method
     m.multiply();
     m.display();
     Add.sum();//static method calling static method
     Add i=new Add();
     i.imul();//static method calling static method
     i.jmul();
     System.out.println("End of main method");
   }
}