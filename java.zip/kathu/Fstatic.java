import java.lang.*;
class Fstatic
{
   void display()
   {
     System.out.println("show display method");
     display1();
    }
   static void show()
   {
    System.out.println("show static method");
    Fstatic f=new Fstatic();
    f.display();
   }
   void display1()
   {
     System.out.println("show display1 method"); 
    }
    public static void main(String k[])
   {
     System.out.println("main method");
     show();
    }
}
