import java.lang.*;
class Ftypeconversion
{
   public static void main(String u[])
   {
     int y='a';
     System.out.println(y);
     float g=67;
     System.out.println(g);
     int k=663;
     byte d=(byte)k;
     System.out.println(d);
     long h=456785678;
     float c=(float)h;
     System.out.println(c);
   }
}